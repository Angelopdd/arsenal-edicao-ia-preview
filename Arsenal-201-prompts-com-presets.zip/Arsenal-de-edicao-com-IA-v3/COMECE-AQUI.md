# Arsenal de edição com IA

## Comece pela sua profissão

Este pacote reúne 201 prompts completos, organizados em 18 áreas, com uma combinação de edição recomendada para cada profissão e especialização. Cada prompt inclui a direção visual, a cena temática, o ritmo, a legenda, as regiões a preservar e o fluxo de revisão.

Abra [INDICE.md](INDICE.md), escolha sua profissão e copie apenas o bloco **Prompt para copiar**. O mesmo acervo está disponível em [TODOS-OS-201-PROMPTS.md](TODOS-OS-201-PROMPTS.md), e a visão das combinações em [MAPA-DE-PRESETS.md](MAPA-DE-PRESETS.md).

## Para usar

1. Tenha o Claude Code local e acesso legítimo à skill **do-bruto-ao-pronto**, com o ambiente preparado conforme as instruções recebidas com ela. A assinatura, a instalação da skill e os vídeos não estão incluídos neste pacote.
2. Coloque o vídeo e os materiais de apoio em uma pasta do computador. Use o caminho completo do arquivo no campo **Vídeo**, por exemplo: `C:\MeusVideos\gravacao.mp4`.
3. Copie o prompt completo da sua profissão e cole no Claude Code com acesso à pasta do vídeo. Preencha as demais preferências apenas se quiser escolher.
4. Confira e aprove a fala limpa. Essa primeira etapa pode ter só cortes e uma legenda de conferência. Os elementos visuais fazem parte da montagem seguinte.
5. Confira a revisão com as cenas, as legendas e o som. Ouça o áudio e peça correções com o instante e o problema observado. Aprove a versão final para receber os arquivos conforme a skill.

Sem preenchimento, o prompt mantém a orientação gravada, 1080p30 e conteúdo completo. O preset da profissão orienta a montagem, mas se adapta ao cenário, à densidade da explicação e aos materiais existentes. Um pedido de duração menor pode exigir uma decisão sua se eliminar informação essencial.

## Como escolher a direção

- **RECOMENDADO DESTA PROFISSÃO:** parte da combinação incluída no prompt, com ajustes ao vídeo. É a escolha padrão quando o campo fica sem preenchimento.
- **AUTOMÁTICO LIVRE:** o Claude escolhe outra combinação adequada à gravação e à explicação.
- **DESCREVER:** você informa a direção desejada. Uma referência e suas preferências têm prioridade sobre o perfil recomendado.

Os campos **Estilo visual**, **Legenda** e **Complementos** permitem refinar escolhas separadamente. Por exemplo: `Legenda: convencional, discreta, com blocos estáveis`. Em `Complementos: NENHUM`, a edição mantém cortes, enquadramento e legendas, sem figuras ou outros apoios extras.

## Grave para a imagem ajudar a explicar

Use as orientações **Antes de gravar** do seu arquivo. Fale uma ideia central com etapas claras. Em demonstrações, mantenha a ferramenta, as mãos e a região trabalhada visíveis. Forneça plantas, fotos, diagramas, telas, dados e outros registros que realmente pertençam ao assunto apresentado.

Os exemplos dos prompts são condicionais: uma cena entra quando a fala a justifica. Um relato pode pedir cartões e uma sequência ilustrativa; uma demonstração pode ficar melhor com o próprio gesto em destaque. Não é necessário inserir todos os recursos do perfil.

## O que este pacote entrega

Os presets são **perfis autorais de direção incluídos nos prompts**. O Claude precisa transformar essas orientações em configurações e cenas no projeto. Eles não são 201 plugins ou efeitos nativos novos, nem arquivos prontos para substituir diretamente o plano.json. Leia [COMO-OS-PRESETS-FUNCIONAM.md](COMO-OS-PRESETS-FUNCIONAM.md).

Esta revisão tem conferência editorial e estrutural, com o alcance registrado no relatório. O usuário aprovou externamente um vídeo feito com o prompt de arquiteto da versão anterior; os 201 prompts com os novos perfis precisam de validação em vídeo. Use [PLANO-DE-TESTES.md](PLANO-DE-TESTES.md) e registre os resultados em CONTROLE-DE-TESTES.csv. Um teste representativo de uma área não certifica automaticamente todas as profissões dela.

Este pacote não redistribui a skill, código do motor, bibliotecas de som, modelos 3D nem materiais profissionais. Os arquivos da versão anterior foram preservados. A biblioteca em página usa esta revisão; o PDF anterior permanece pausado e não está incluído como versão atualizada.
