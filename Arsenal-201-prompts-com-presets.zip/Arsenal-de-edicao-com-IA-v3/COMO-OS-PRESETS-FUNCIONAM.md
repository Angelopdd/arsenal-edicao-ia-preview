# Como os presets são aplicados

## Uma combinação ligada ao assunto

Cada profissão tem um perfil com identidade visual, tratamento de legenda, par de fontes para ênfases, ritmo, recursos possíveis e uma cena temática. O objetivo é tornar a explicação mais compreensível. As diferenças surgem do que precisa ser visto: estrutura, percurso, comparação, detalhe, gesto ou sequência narrada.

Um perfil de barbearia pode destacar uma região real do corte; arquitetura pode mostrar circulação numa planta fornecida; uma aula pode revelar uma relação por etapas. São exemplos de aplicação, e cada cena depende do conteúdo efetivamente gravado. A imagem deve estar reconhecível quando a ideia for mencionada e acompanhar a evolução da fala.

## Preferências e adaptação

As escolhas explícitas e as referências do cliente têm prioridade. O recomendado é um ponto de partida, com cores ajustadas para contraste e o cenário. AUTOMÁTICO LIVRE permite ao Claude escolher outra combinação. NENHUM em complementos desliga os apoios extras, preservando cortes, enquadramento e legendas.

Usar um recurso em várias profissões não torna os perfis iguais: a combinação completa, o motivo gráfico e a cena são diferentes. Não é preciso inventar 201 ferramentas ou usar uma cor aleatória em cada vídeo para distinguir as direções.

## Recursos existentes e cenas que precisam ser escritas

| Parte do perfil | Como é concretizada na cópia do projeto |
|---|---|
| Base, destaque e par de ênfase | Configurações reconhecidas pelo motor em plano.json e composições de ênfase. |
| Cor do texto | Orientação aplicada e conferida em cada componente; um campo global pode não alterar a legenda ou a cena. |
| Reenquadramentos, listas, recuo, órbitas e texto atrás | Controles existentes, com horários e conteúdo adequados. Órbitas/texto atrás dependem de recorte válido. |
| Diagramas, trajetos, destaques temáticos e composições sobre materiais | Receitas implementadas nas cenas do projeto, com os recursos existentes e movimento em função do tempo/quadro. |
| Legenda convencional ou editorial | Alteração implementada e conferida no componente da cópia do projeto. O nome do modo não funciona sozinho como seletor. |
| Som | Arquivos disponíveis e licenciados, com volume medido e sincronização. |

O nome AEIA-001, por exemplo, identifica um perfil deste produto; não é comando reconhecido automaticamente pela skill. `presets-editoriais.json` é um catálogo autoral para consulta e leitura pelo agente, não um plano.json nativo. Acrescentar uma chave ao JSON sem uma parte do código que a utilize pode não produzir efeito no vídeo. O prompt exige verificar o resultado visível.

Os sete pares indicados nos perfis pertencem às **composições de ênfase**. Eles não representam sete renderizadores completos de legenda. As famílias de estilo também são direções descritivas. A execução exige transformar a escolha em campos consumidos e em código de cenas quando necessário.

## Como interpretar o 3D

Profundidade gráfica em cartões e texto é diferente de um modelo anatômico, arquitetônico ou mecânico correto. A skill não inclui um gerador desses modelos. Uma figura técnica 3D depende de material compatível, adequado ao que foi dito e conferido antes de usar. Sem esse material, o perfil indica um esquema 2D identificado como ilustrativo. A demonstração real continua sendo a prioridade quando já mostra o conceito.

Nenhum preset autoriza inventar estruturas, medidas, etapas, resultados ou antes/depois. Os elementos devem corresponder à fala e às referências do autor do vídeo. Dados, termos e representações técnicas exigem revisão pelo responsável pelo conteúdo.

## O que conferir no teste

Além de cortes e legibilidade, verifique se o preset foi implementado, se o elemento certo aparece no momento da fala e se ajuda a explicar. Confira primeiro a abertura e depois cada etapa relevante. Um efeito atrasado, um desenho incorreto ou uma região importante encoberta deve ser corrigido mesmo quando o comando de render termina sem erro.

O funcionamento final depende do vídeo, dos materiais, do ambiente e da implementação produzida pelo Claude. A revisão do texto e os testes estruturais não equivalem à validação de 201 edições reais. Consulte o relatório desta revisão e registre a execução no controle de testes.

Os prompts orientam o uso legítimo da skill já instalada e personalizações na cópia de cada projeto. Não incluem nem modificam sua instalação global, e não incorporam o código ou os ativos restritos da skill ao produto.
