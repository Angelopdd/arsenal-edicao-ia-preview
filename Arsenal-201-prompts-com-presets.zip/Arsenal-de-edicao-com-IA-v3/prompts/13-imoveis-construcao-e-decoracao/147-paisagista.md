# 147 · Paisagista

**Área:** Imóveis, construção e decoração

**Preset recomendado:** Paisagem entre plano e implantação · AEIA-147

**Para que serve:** Apresentar escolhas e etapas de paisagismo relacionando espaço, espécies e materiais fornecidos, preservando a distinção entre plano, implantação registrada e aparência real da vegetação mostrada no vídeo.

**Antes de gravar:** Grave o espaço inteiro e detalhes das plantas ou materiais comentados, com identificação dos arquivos. Forneça a planta autorizada quando usada e diferencie na fala a proposta e o que já está implantado.

**Ideia para testar:** Apresente um espaço autorizado e uma escolha narrada, sem gerar crescimento ou identificar espécies por suposição.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Paisagista**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Paisagem entre plano e implantação (AEIA-147)**

- Identidade: pessoa e interface + editorial; base #263028, destaque #C4D2AC, texto #FFFFFF.
- Ênfases: par humanista-fino. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Mantenha nomes fornecidos de espécies e condições em frases estáveis, fora da vegetação observada; preserve a distinção entre escolha de projeto, implantação e estado real mostrado.
- Ritmo: Siga a relação entre área, escolha e implantação na ordem narrada; dê tempo para reconhecer a espécie ou material, sem acelerar registros para simular evolução do jardim.
- Motivo visual: Área de planta fornecida conectada à espécie ou material documentado, com etapas de implantação identificadas sem criar crescimento vegetal ou composição presumida.
- Recursos disponíveis para esta direção: checklist sincronizado aos itens narrados (listas); vídeo em janela, com fundo coberto (recuo).
- Cena temática (composição sobre material fornecido): Quando o paisagista explicar uma área, espécie ou material, use a planta e registros correspondentes, mantendo as identificações fornecidas e a relação espacial efetivamente descrita. Localize a área citada, revele o registro da espécie ou material autorizado e conecte à implantação quando documentada; identifique proposta e estado real, sem completar vegetação, prever porte ou atribuir condições que não foram informadas.
- Preserve no enquadramento: Preserve identificação fornecida de espécies, contexto espacial, escala documentada e aparência real da vegetação e dos materiais apresentados.
- 3D: Modelo paisagístico 3D só com material fornecido e projeto conferido; sem ele, use planta real ou esquema 2D ilustrativo, sem simular crescimento ou porte futuro.
- Cuidado específico: Não adicione flores, volume ou maturidade vegetal para transformar implantação recente em resultado consolidado do projeto.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se explicar distribuição, mostre a planta fornecida em cartão e destaque as áreas narradas com traços SVG; não crie posição, escala ou quantidade de espécies que não estejam no material.

- Quando apresentar plantas ou materiais, use rótulos apenas com identificações fornecidas e preserve sua aparência real; não acrescente floração, volume ou cor para ilustrar um resultado desejado como existente.

- Se mostrar evolução ou implantação, use registros datados quando disponíveis e cartões de contexto; diferencie etapa de execução, proposta e expectativa, sem simular crescimento futuro como evidência do resultado.

Confira nomes, quantidades e condições narradas. Não deduza espécies pela imagem, invente porte futuro, clima adequado ou instruções de manutenção; preserve cores, escala e a distinção entre situação real e representação ilustrativa.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```
