# 009 · Médico neurologista

**Área:** Medicina

**Preset recomendado:** Mapa neural orientado · AEIA-009

**Para que serve:** Acompanhar explicações neurológicas com trajetos e estruturas identificáveis, evitando que metáforas ou imagens criadas aparentem evidência de um exame real.

**Antes de gravar:** Anuncie quando passar da estrutura ao funcionamento na explicação. Se comentar uma imagem, prepare uma cópia sem identificação e aponte o detalhe para que a edição preserve a referência correta.

**Ideia para testar:** Apresente uma estrutura em um modelo didático e explique sua localização conforme o roteiro.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Médico neurologista**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Mapa neural orientado (AEIA-009)**

- Identidade: pessoa e interface + tipografia didática; base #20283B, destaque #B4CAE8, texto #FFFFFF.
- Ênfases: par humanista-fino. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Manter termos anatômicos inteiros e a direção da relação em frases claras; evitar destacar um nome enquanto o rótulo aponta para outra estrutura.
- Ritmo: Avançar da estrutura citada ao trajeto explicado, conservando a vista de referência; cada aproximação precisa manter a orientação compreensível para quem assiste.
- Motivo visual: Mapa anatômico identificado com percursos progressivos e janela de detalhe preserva orientação entre visão geral e região explicada.
- Recursos disponíveis para esta direção: vídeo em janela, com fundo coberto (recuo); reenquadramentos pontuais (planos).
- Cena temática (receita 2D a implementar): Quando o neurologista localizar uma estrutura ou descrever uma comunicação entre regiões, com orientação explícita e suporte suficiente na fala ou material fornecido. Exibir a vista de referência e identificar a região mencionada. Ampliar mantendo um pequeno mapa de localização; desenhar somente o percurso explicado, distinguindo esquema ilustrativo de exame real e preservando os rótulos entre as vistas.
- Preserve no enquadramento: Preservar a orientação da imagem, os limites de exames fornecidos e as diferenças entre função explicada e achado documentado.
- 3D: Giro anatômico requer material fornecido e conferido para a vista e o trajeto citados; sem ele, mapa 2D rotulado com orientação consistente.
- Cuidado específico: Não inventar imagens de ressonância, pulsos neuronais ou localização exata de funções a partir de metáforas.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se o tema envolver localização anatômica, desenhe um mapa 2D da região com orientação constante e destaque o ponto citado. Use vistas adicionais para profundidade; modelo 3D somente com material compatível disponível e conferido.

- Quando descrever transmissão ou percurso, anime um traço pelo trajeto narrado, sem inventar velocidades, conexões ou resultados. Identifique a representação como didática e diferencie uma metáfora de comunicação de anatomia literal.

Verifique nomes, lateralidade e direção dos percursos. Não substitua exames por imagens geradas nem associe um sintoma a uma região específica quando a fala não estabeleceu essa relação.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```
