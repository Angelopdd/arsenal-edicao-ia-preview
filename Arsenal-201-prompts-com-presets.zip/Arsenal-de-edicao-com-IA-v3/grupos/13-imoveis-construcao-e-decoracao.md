# 13 · Imóveis, construção e decoração

10 prompts completos com direções próprias.

# 142 · Corretor de imóveis

**Área:** Imóveis, construção e decoração

**Preset recomendado:** Percurso imobiliário sem distorção · AEIA-142

**Para que serve:** Editar apresentações e explicações imobiliárias conectando ambientes e informações fornecidas, preservando dimensões aparentes, condições reais e a diferença entre registro do imóvel e proposta ilustrativa de utilização.

**Antes de gravar:** Filme os ambientes com movimento estável e identifique os registros por cômodo. Forneça planta e condições autorizadas quando forem comentadas, evitando expor moradores, documentos, endereços privados e itens pessoais identificáveis.

**Ideia para testar:** Apresente dois ambientes autorizados e explique a ligação entre eles sem alterar a percepção do espaço.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Corretor de imóveis**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Percurso imobiliário sem distorção (AEIA-142)**

- Identidade: pessoa e interface + editorial; base #29302D, destaque #D2CCB2, texto #FFFFFF.
- Ênfases: par humanista-fino. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Use frases estáveis fora de portas e detalhes do ambiente, mantendo características e condições completas; preserve identificação de cômodos e não transforme uma proposta de uso em situação real.
- Ritmo: Acompanhe o percurso espacial sem saltos que confundam a conexão entre ambientes; mantenha cada vista tempo suficiente para reconhecer o ponto citado e as condições efetivamente informadas.
- Motivo visual: Ambientes reais conectados pelo percurso registrado, com rótulos de localização e planta fornecida usada apenas quando houver correspondência verificável entre as vistas.
- Recursos disponíveis para esta direção: reenquadramentos pontuais (planos); checklist sincronizado aos itens narrados (listas).
- Cena temática (destaque da demonstração real): Quando o corretor explicar a relação entre ambientes ou uma característica do imóvel, use a tomada correspondente e a planta fornecida, quando sua correspondência estiver conferida. Identifique o ambiente, destaque a passagem ou característica citada e acompanhe o deslocamento real; se houver planta, marque o ponto correspondente sem inventar dimensões, preservando a distinção entre registro do imóvel e sugestão ilustrativa de uso.
- Preserve no enquadramento: Preserve proporção aparente, passagens, condições reais e identificação de ambientes, sem ocultar elementos relevantes da apresentação do imóvel.
- 3D: Tour ou modelo 3D somente se fornecido e correspondente ao imóvel; sem ele, priorize percurso real ou planta 2D identificada, sem reconstruir dimensões e ambientes não registrados.
- Cuidado específico: Não alargue ambientes, elimine obstáculos ou apresente decoração e reforma simuladas como estado real do imóvel.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se apresentar um imóvel, mantenha a continuidade espacial entre ambientes e use rótulos com os nomes narrados; evite zooms ou recortes que façam um espaço parecer maior ou esconderem condições relevantes.

- Quando relacionar planta e vídeo, use somente o desenho fornecido em cartão e destaque o cômodo correspondente com contorno SVG; não reconstrua medidas, circulação ou orientação por suposição.

- Se explicar uma característica ou possibilidade de uso, associe o comentário ao registro real e identifique propostas; não remova objetos, gere vista externa ou acrescente acabamento como se já existisse.

Confira identificação, áreas, valores e condições contra os materiais. Não invente regularidade, disponibilidade, metragem, localização ou retorno; preserve perspectiva e diferencie fotografia real, planta fornecida e representação ilustrativa claramente identificada.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 143 · Arquiteto

**Área:** Imóveis, construção e decoração

**Preset recomendado:** Espaço, circulação e escolha arquitetônica · AEIA-143

**Para que serve:** Editar explicações, apresentações de projeto e relatos com apoios visuais fiéis, preservando a relação entre espaço, circulação e materiais.

**Antes de gravar:** Grave uma ideia central com suas etapas e indique o que é relato ou exemplo. Se mostrar projeto, forneça plantas, fotos e renders legíveis, identificando a versão e os elementos citados.

**Ideia para testar:** Explique uma relação entre mobiliário e circulação usando um relato ou uma planta identificada.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Arquiteto**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Espaço, circulação e escolha arquitetônica (AEIA-143)**

- Identidade: pessoa e interface + editorial; base #2C2D2B, destaque #D8C8AB, texto #FFFFFF.
- Ênfases: par geometrica-serifa. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Use frases estáveis com relações espaciais completas, posicionadas fora da planta e do percurso; preserve condições e relatos, reservando ênfase para a escolha arquitetônica efetivamente explicada.
- Ritmo: Siga a lógica do relato ou projeto, revelando cada elemento na sua menção; mantenha o movimento espacial enquanto a fala explicar causa, consequência e solução, sem atraso narrativo.
- Motivo visual: Planta fornecida ou esquema ilustrativo de ambiente, com objeto, abertura e percurso revelados pela fala e critérios arquitetônicos ligados à decisão narrada.
- Recursos disponíveis para esta direção: reenquadramentos pontuais (planos); checklist sincronizado aos itens narrados (listas).
- Cena temática (receita 2D a implementar): Quando o arquiteto explicar uma relação entre objeto, circulação ou rotina, use primeiro material real do projeto; em relatos sem arquivos, crie apenas esquema ilustrativo. Localize o elemento citado no início da explicação e revele a relação espacial quando narrada; se houver obstáculo, mostre-o naquele momento e só altere o percurso ao explicar a mudança, sem inventar medidas ou solução técnica.
- Preserve no enquadramento: Preserve proporções do material real, aberturas e lógica espacial; mantenha esquema de relato claramente separado de projeto executável.
- 3D: Modelo arquitetônico 3D só se fornecido e compatível com o projeto explicado; sem geometria conferida, use planta real ou esquema 2D ilustrativo, sem reconstrução técnica presumida.
- Cuidado específico: Não use ambiente genérico como projeto do autor nem antecipe solução ou atrase o elemento citado na narração.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Priorizar plantas, fotos, renders e vídeos fornecidos, com marcações acompanhando a circulação, abertura ou material mencionado; quando necessário, usar esquema identificado como ilustrativo.

- Diferenciar estudo, render, proposta e execução; preservar proporções e características do projeto e usar comparações somente com arquivos correspondentes.

Preserve proporções e características do projeto. Diferencie estudo, render, proposta e obra executada. Comparações exigem arquivos correspondentes; não invente plantas, cotas, normas ou resultados. Na ausência de material, use um esquema conceitual identificado como ilustrativo.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 144 · Engenheiro civil

**Área:** Imóveis, construção e decoração

**Preset recomendado:** Componente, etapa e evidência de engenharia · AEIA-144

**Para que serve:** Apresentar explicações e registros de engenharia com etapas e componentes legíveis, preservando os dados fornecidos e distinguindo representação didática de projeto, ensaio ou execução tecnicamente comprovados.

**Antes de gravar:** Grave uma etapa ou componente e forneça desenhos autorizados que serão comentados. Mantenha escalas, legendas e medições legíveis, sem expor dados privados do projeto ou bloquear a área demonstrada.

**Ideia para testar:** Explique um desenho autorizado e destaque seus elementos sem acrescentar medidas ou conclusões de segurança.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Engenheiro civil**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Componente, etapa e evidência de engenharia (AEIA-144)**

- Identidade: pessoa e interface + tipografia didática; base #253039, destaque #BDCED9, texto #FFFFFF.
- Ênfases: par editorial-leve. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Mantenha termos, medidas e condições em frases estáveis, fora do componente demonstrado; preserve ressalvas técnicas e a diferença entre explicação didática, projeto fornecido e execução documentada.
- Ritmo: Siga a relação entre componente e etapa narrada, mantendo o registro enquanto suas condições forem explicadas; não elimine trechos necessários para distinguir observação, ensaio e conclusão.
- Motivo visual: Componente real conectado à vista de projeto ou etapa documentada, com rótulos técnicos fornecidos e identificação clara de esquema didático ou evidência.
- Recursos disponíveis para esta direção: checklist sincronizado aos itens narrados (listas); vídeo em janela, com fundo coberto (recuo).
- Cena temática (composição sobre material fornecido): Quando o engenheiro explicar um componente ou etapa de execução, use o projeto e registros correspondentes, limitando as marcações ao que for narrado e fornecido. Mostre o conjunto, destaque a região citada e conecte à vista ou etapa pertinente; mantenha identificação de documentos e ensaios quando fornecidos, separando esquema ilustrativo de execução real sem completar dimensões, cargas ou conclusões técnicas.
- Preserve no enquadramento: Preserve escala, referências, unidades e condições documentadas, mantendo o contexto necessário para interpretar o registro de engenharia.
- 3D: Geometria 3D só com modelo fornecido e correspondência conferida ao projeto; na falta, prefira vista documental ou esquema 2D ilustrativo, sem cálculo ou reconstrução estrutural.
- Cuidado específico: Não anime resistência, estabilidade ou conformidade como prova técnica nem invente armadura, dimensão ou carga para preencher o esquema.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se explicar uma composição ou etapa construtiva, escreva um esquema 2D com cartões, contornos e rótulos derivados da fala; identifique a ilustração sem simular cálculo, resistência ou comportamento estrutural.

- Quando comentar projeto ou medição, mostre o arquivo original em janela e destaque o trecho correspondente; mantenha unidade, orientação e contexto, sem completar cotas ou detalhes ausentes.

- Se apresentar evolução da obra, associe os registros às etapas efetivamente identificadas; preserve esperas e condições relevantes no contexto, sem transformar montagem editorial em prova de execução contínua ou conformidade.

Confira componentes, medidas e termos contra a fonte. Não invente dimensionamento, cargas, materiais, prazos ou validação técnica; diagramas da edição não substituem projeto, laudo ou avaliação profissional da construção apresentada.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 145 · Designer de interiores

**Área:** Imóveis, construção e decoração

**Preset recomendado:** Material e uso no mesmo ambiente · AEIA-145

**Para que serve:** Editar apresentações de interiores relacionando escolhas, materiais e ambiente, preservando cores e proporções reais e distinguindo propostas visuais de resultados efetivamente executados no projeto apresentado pelo profissional.

**Antes de gravar:** Mostre o ambiente inteiro e depois os detalhes comentados sob iluminação consistente. Forneça plantas, amostras e imagens autorizadas, identificando claramente o que é proposta, render fornecido e registro do espaço executado.

**Ideia para testar:** Apresente uma escolha de material com amostra e imagem autorizada, identificando proposta ou resultado real.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Designer de interiores**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Material e uso no mesmo ambiente (AEIA-145)**

- Identidade: pessoa e interface + editorial; base #302E2A, destaque #D7C6AA, texto #FFFFFF.
- Ênfases: par fino-italico. Legenda: Editorial: blocos discretos integrados à composição. Integre frases discretas à área livre, preservando motivo e condição da escolha; mantenha amostras e ambiente visíveis sem duplicar títulos ou cobrir o detalhe de material.
- Ritmo: Apresente o ambiente antes da amostra e retorne ao contexto após o detalhe, acompanhando a justificativa narrada; identifique proposta e execução sem transições que misturem seus estados.
- Motivo visual: Amostra de material ligada ao ponto de aplicação no ambiente, mantendo projeto e execução identificados e cores reais preservadas na comparação.
- Recursos disponíveis para esta direção: vídeo em janela, com fundo coberto (recuo); reenquadramentos pontuais (planos).
- Cena temática (composição sobre material fornecido): Quando o designer explicar a escolha de um material ou solução de uso, relacione a amostra fornecida à área correspondente do ambiente ou projeto apresentado. Mostre o ambiente, destaque o ponto citado e revele a amostra autorizada junto à justificativa narrada; retorne ao conjunto para situar a escolha, identificando render e execução sem alterar acabamento, cor ou proporção dos registros.
- Preserve no enquadramento: Preserve cor, textura, proporção e estado do ambiente, mantendo os materiais corretamente relacionados à aplicação apresentada.
- 3D: Render ou modelo 3D somente se fornecido e compatível com a proposta explicada; sem ele, use ambiente real ou prancha 2D ilustrativa, sem simular obra concluída.
- Cuidado específico: Não substitua material, melhore iluminação ou apresente render como fotografia de ambiente executado para valorizar o resultado.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se explicar uma escolha de composição, destaque o item citado com rótulo ou contorno SVG sobre a imagem real; preserve sua proporção e a relação com os demais elementos do ambiente.

- Quando apresentar materiais, use cartões com as amostras fornecidas e conecte cada uma ao comentário; não aplique filtros que alterem cor, textura ou a diferença usada para sustentar a escolha.

- Se comparar projeto e execução, mantenha rótulos explícitos e enquadramentos compatíveis; não gere mobiliário, iluminação ou acabamentos para apresentar uma proposta como se fosse fotografia de um espaço concluído.

Confira materiais, medidas e estado do projeto com os arquivos. Não invente especificações, viabilidade ou resultado executado; preserve perspectiva e cores e identifique qualquer representação ilustrativa ou imagem de projeto fornecida.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 146 · Decorador

**Área:** Imóveis, construção e decoração

**Preset recomendado:** Composição decorativa em relações visíveis · AEIA-146

**Para que serve:** Valorizar explicações e montagens de decoração com detalhes e relações visuais claras, preservando os objetos reais e a diferença entre sugestão de composição e ambiente efetivamente montado.

**Antes de gravar:** Filme a composição inteira e os objetos que irá comentar, sem mudar a iluminação entre registros comparados. Disponibilize imagens autorizadas de antes e depois, identificando quando mostrar apenas uma proposta demonstrativa.

**Ideia para testar:** Monte uma composição simples com objetos próprios e explique uma escolha mantendo os registros reais.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Decorador**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Composição decorativa em relações visíveis (AEIA-146)**

- Identidade: pessoa e interface + editorial; base #312C29, destaque #DBC6AE, texto #FFFFFF.
- Ênfases: par grotesca-italico. Legenda: Editorial: blocos discretos integrados à composição. Use frases discretas fora dos objetos da composição, mantendo critérios e preferências completos; reserve a ênfase para a relação citada e preserve a aparência real dos itens.
- Ritmo: Permita observar o conjunto e a colocação de cada objeto, seguindo a explicação; em comparações, mantenha vistas equivalentes e identifique o que é montagem real ou sugestão.
- Motivo visual: Objetos reais agrupados por relações narradas de composição, com chamadas sutis e vistas equivalentes que permitem observar a montagem efetivamente realizada.
- Recursos disponíveis para esta direção: reenquadramentos pontuais (planos); checklist sincronizado aos itens narrados (listas).
- Cena temática (destaque da demonstração real): Quando o decorador explicar uma relação entre objetos ou uma mudança de composição, use a montagem fornecida e destaque os elementos correspondentes ao comentário narrado. Apresente o conjunto, marque o objeto citado e acompanhe a mudança real de posição ou agrupamento; retorne à visão geral para mostrar a relação, identificando qualquer sugestão ilustrativa sem criar um ambiente final que não foi montado.
- Preserve no enquadramento: Preserve escala relativa, cor e posição dos objetos, mantendo a composição e as condições de comparação fielmente reconhecíveis.
- 3D: Objetos ou ambiente 3D apenas com material fornecido e pertinente à composição explicada; sem ele, use registros reais ou prancha 2D ilustrativa sem inventar montagem concluída.
- Cuidado específico: Não multiplique objetos, altere proporções ou apague elementos para produzir um equilíbrio visual que a montagem real não apresenta.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se explicar distribuição ou combinação, use rótulos e traços discretos para relacionar os itens citados; mantenha o ambiente visível e evite que textos ou recorte da pessoa escondam a composição.

- Quando demonstrar montagem, preserve a sequência real e use cartões de etapas apenas quando ajudarem a compreender a escolha; não acrescente objetos gerados para preencher vazios ou melhorar o resultado.

- Se comparar antes e depois, alinhe registros do mesmo ambiente e identifique condições diferentes; mantenha clara a distinção entre montagem real, referência autorizada e colagem ilustrativa criada a partir de materiais fornecidos.

Confira itens, cores e vínculo entre registros. Não altere proporções, iluminação ou quantidade de objetos para fabricar melhoria, nem atribua medidas, materiais, custos ou disponibilidade que não tenham sido informados.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 147 · Paisagista

**Área:** Imóveis, construção e decoração

**Preset recomendado:** Paisagem entre plano e implantação · AEIA-147

**Para que serve:** Apresentar escolhas e etapas de paisagismo relacionando espaço, espécies e materiais fornecidos, preservando a distinção entre plano, implantação registrada e aparência real da vegetação mostrada no vídeo.

**Antes de gravar:** Grave o espaço inteiro e detalhes das plantas ou materiais comentados, com identificação dos arquivos. Forneça a planta autorizada quando usada e diferencie na fala a proposta e o que já está implantado.

**Ideia para testar:** Apresente um espaço autorizado e uma escolha narrada, sem gerar crescimento ou identificar espécies por suposição.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Paisagista**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Paisagem entre plano e implantação (AEIA-147)**

- Identidade: pessoa e interface + editorial; base #263028, destaque #C4D2AC, texto #FFFFFF.
- Ênfases: par humanista-fino. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Mantenha nomes fornecidos de espécies e condições em frases estáveis, fora da vegetação observada; preserve a distinção entre escolha de projeto, implantação e estado real mostrado.
- Ritmo: Siga a relação entre área, escolha e implantação na ordem narrada; dê tempo para reconhecer a espécie ou material, sem acelerar registros para simular evolução do jardim.
- Motivo visual: Área de planta fornecida conectada à espécie ou material documentado, com etapas de implantação identificadas sem criar crescimento vegetal ou composição presumida.
- Recursos disponíveis para esta direção: checklist sincronizado aos itens narrados (listas); vídeo em janela, com fundo coberto (recuo).
- Cena temática (composição sobre material fornecido): Quando o paisagista explicar uma área, espécie ou material, use a planta e registros correspondentes, mantendo as identificações fornecidas e a relação espacial efetivamente descrita. Localize a área citada, revele o registro da espécie ou material autorizado e conecte à implantação quando documentada; identifique proposta e estado real, sem completar vegetação, prever porte ou atribuir condições que não foram informadas.
- Preserve no enquadramento: Preserve identificação fornecida de espécies, contexto espacial, escala documentada e aparência real da vegetação e dos materiais apresentados.
- 3D: Modelo paisagístico 3D só com material fornecido e projeto conferido; sem ele, use planta real ou esquema 2D ilustrativo, sem simular crescimento ou porte futuro.
- Cuidado específico: Não adicione flores, volume ou maturidade vegetal para transformar implantação recente em resultado consolidado do projeto.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se explicar distribuição, mostre a planta fornecida em cartão e destaque as áreas narradas com traços SVG; não crie posição, escala ou quantidade de espécies que não estejam no material.

- Quando apresentar plantas ou materiais, use rótulos apenas com identificações fornecidas e preserve sua aparência real; não acrescente floração, volume ou cor para ilustrar um resultado desejado como existente.

- Se mostrar evolução ou implantação, use registros datados quando disponíveis e cartões de contexto; diferencie etapa de execução, proposta e expectativa, sem simular crescimento futuro como evidência do resultado.

Confira nomes, quantidades e condições narradas. Não deduza espécies pela imagem, invente porte futuro, clima adequado ou instruções de manutenção; preserve cores, escala e a distinção entre situação real e representação ilustrativa.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 148 · Mestre de obras

**Área:** Imóveis, construção e decoração

**Preset recomendado:** Execução de obra com sequência legível · AEIA-148

**Para que serve:** Editar explicações e registros de obra destacando execução, ferramentas e sequência real, sem transformar cortes temporais em instruções incompletas ou prova de conformidade técnica da construção apresentada.

**Antes de gravar:** Enquadre a área de trabalho e o gesto comentado sem interferir na execução. Registre etapas correspondentes e forneça desenhos ou medições que quiser mencionar, evitando expor trabalhadores e dados de terceiros sem autorização.

**Ideia para testar:** Explique uma etapa registrada e aponte o detalhe visível sem acrescentar procedimento ou conclusão técnica.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Mestre de obras**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Execução de obra com sequência legível (AEIA-148)**

- Identidade: pessoa e interface + tipografia didática; base #30302B, destaque #D3C599, texto #FFFFFF.
- Ênfases: par condensada. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Use frases estáveis com termos de execução e condições completos, fora da ferramenta e do ponto de trabalho; não corte ressalvas que expliquem a etapa ou seu contexto.
- Ritmo: Preserve início, gesto e resultado da ação explicada, identificando saltos entre etapas; não acelere nem retire partes essenciais a ponto de transformar registro em procedimento aparentemente completo.
- Motivo visual: Ponto de execução real com rótulo ancorado e sequência documentada, mantendo ferramentas, condições e etapas visíveis sem efeitos de validação técnica.
- Recursos disponíveis para esta direção: reenquadramentos pontuais (planos); checklist sincronizado aos itens narrados (listas).
- Cena temática (destaque da demonstração real): Quando o mestre de obras explicar uma etapa ou detalhe de execução, use a tomada correspondente e destaque a área mencionada sem completar procedimento que não esteja documentado. Mostre o contexto de trabalho, aproxime o ponto citado e acompanhe a ação registrada; identifique a etapa seguinte apenas quando aparecer ou for explicada, preservando condições narradas sem inventar medidas, camadas ou prova de conformidade da obra.
- Preserve no enquadramento: Preserve ferramenta, mãos, ponto de contato e contexto da obra, mantendo visíveis as condições relevantes para compreender a execução.
- 3D: Vista 3D de execução somente com material fornecido e correspondência técnica conferida; sem ele, use registro real anotado ou esquema 2D ilustrativo sem preencher componentes internos.
- Cuidado específico: Não esconda etapa relevante nem use checks, selos ou animações para sugerir segurança e conformidade técnica comprovadas.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se demonstrar uma etapa, mantenha o movimento necessário à compreensão e use rótulos na ferramenta ou área citada; não esconda partes essenciais da execução para acelerar o vídeo.

- Quando explicar uma sequência, escreva cartões ligados aos registros disponíveis e identifique intervalos relevantes conforme a fala; não apresente mudanças de fase como se dispensassem esperas ou conferências mencionadas.

- Se comentar alinhamento ou detalhe construtivo, use traços SVG sobre a imagem real ou desenho fornecido; identifique a função didática e não apresente a sobreposição como medição ou verificação técnica.

Confira ordem, ferramentas e medidas narradas contra os registros. Não invente proporções, prazos, procedimentos ou aprovação técnica; preserve equipamentos e condições visíveis, sem editar um resultado para parecer mais correto do que foi filmado.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 149 · Marceneiro

**Área:** Imóveis, construção e decoração

**Preset recomendado:** Encaixe, montagem e acabamento real · AEIA-149

**Para que serve:** Apresentar processos e acabamentos de marcenaria com gestos e peças legíveis, preservando medidas fornecidas e a correspondência entre material, montagem e resultado real mostrado pelo profissional no vídeo.

**Antes de gravar:** Grave a peça inteira e aproxime o detalhe comentado sem bloquear mãos ou ferramentas. Forneça desenho e medidas quando necessários, mantendo números legíveis e registros identificados da mesma montagem ou acabamento.

**Ideia para testar:** Apresente um encaixe ou acabamento de peça própria, com o detalhe real e as medidas apenas quando fornecidas.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Marceneiro**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Encaixe, montagem e acabamento real (AEIA-149)**

- Identidade: pessoa e interface + editorial; base #302B25, destaque #D9C099, texto #FFFFFF.
- Ênfases: par geometrica-serifa. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Mantenha frases estáveis fora da linha de corte e do encaixe, com medidas e condições completas; destaque o nome da parte sem ocupar a superfície do acabamento.
- Ritmo: Acompanhe a relação entre partes antes de mostrar o conjunto montado, preservando o gesto relevante; mantenha o acabamento em observação sem fabricar continuidade entre etapas não registradas.
- Motivo visual: Partes reais identificadas e conectadas ao encaixe correspondente, com montagem observável e detalhe do acabamento preservado sem corrigir textura ou alinhamento por edição.
- Recursos disponíveis para esta direção: reenquadramentos pontuais (planos); checklist sincronizado aos itens narrados (listas).
- Cena temática (destaque da demonstração real): Quando o marceneiro explicar um encaixe, montagem ou acabamento, use a peça e o registro correspondentes, limitando marcações às relações efetivamente descritas ou visíveis. Apresente as partes em contexto, destaque o ponto citado e acompanhe o encaixe real; se a união interna não estiver visível, use esquema 2D ilustrativo baseado no material fornecido, sem acrescentar ferragem, medida ou resultado não demonstrado.
- Preserve no enquadramento: Preserve mãos, ferramentas, encaixe, veios e referência de escala, mantendo medidas fornecidas e acabamento real corretamente visíveis.
- 3D: Vista explodida 3D só com modelo fornecido e peças conferidas da montagem; sem ele, use tomada real ou esquema 2D ilustrativo que não invente encaixes.
- Cuidado específico: Não complete ferragens, elimine folgas ou altere textura para apresentar um encaixe e acabamento melhores que os registrados.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se explicar encaixe ou montagem, use contornos e rótulos na imagem real; quando necessário, escreva um esquema 2D das partes narradas, sem inventar geometria interna ou detalhamento técnico ausente.

- Quando demonstrar um movimento, preserve a continuidade e a relação entre ferramenta, peça e proteção visível; não utilize câmera ou texto que esconda o ponto trabalhado durante a explicação.

- Se apresentar acabamento ou comparação, use registros correspondentes com iluminação semelhante; preserve veios, cor e defeitos reais, diferenciando uma proposta desenhada de um móvel já construído.

Confira unidades, materiais e sequência com os arquivos. Não invente tolerâncias, resistência, dimensões ou regulagens; não apague proteções, falhas ou marcas, nem apresente um esquema editorial como plano de fabricação validado.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 150 · Pintor residencial

**Área:** Imóveis, construção e decoração

**Preset recomendado:** Superfície e aplicação sem retoque · AEIA-150

**Para que serve:** Editar demonstrações e resultados de pintura valorizando preparação, gesto e acabamento reais, preservando cor, textura e contexto para que a comparação não dependa de alterações artificiais na imagem.

**Antes de gravar:** Filme a superfície inteira e o detalhe trabalhado sob iluminação estável. Grave antes e depois da mesma área e forneça identificação dos materiais ou leituras que serão comentados, sem alterar filtros entre tomadas.

**Ideia para testar:** Mostre uma amostra própria e explique um detalhe do acabamento mantendo iluminação e cor consistentes.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Pintor residencial**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Superfície e aplicação sem retoque (AEIA-150)**

- Identidade: pessoa e interface + editorial; base #2D3032, destaque #C9D3D8, texto #FFFFFF.
- Ênfases: par editorial-leve. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Use frases estáveis fora da faixa de aplicação, preservando nomes de etapas e condições; mantenha a legenda neutra para não contaminar a percepção da cor e cobertura reais.
- Ritmo: Preserve o gesto de aplicação e o tempo necessário para observar a superfície, identificando mudanças de etapa; compare estados sem transições que ocultem diferenças de iluminação ou contexto.
- Motivo visual: Superfície real com área citada contornada e etapas identificadas, mantendo aplicação e acabamento comparáveis sem gradação que altere cor, textura ou cobertura.
- Recursos disponíveis para esta direção: reenquadramentos pontuais (planos); checklist sincronizado aos itens narrados (listas).
- Cena temática (destaque da demonstração real): Quando o pintor explicar preparação, aplicação ou acabamento, use o registro correspondente e destaque a área mencionada sem reconstruir camadas ou corrigir a superfície por edição. Mostre o contexto da parede, acompanhe o gesto citado e aproxime a textura observável; em antes e depois, identifique os registros e preserve condições de luz, sem uniformizar cobertura, remover marcas ou mudar a cor para favorecer o resultado.
- Preserve no enquadramento: Preserve cor, iluminação, textura e limites da superfície, mantendo ferramenta e faixa de aplicação visíveis durante a demonstração.
- 3D: Camadas em 3D somente com material fornecido e estrutura conferida; sem ele, use detalhe real ou esquema 2D ilustrativo sem criar espessura ou composição técnica.
- Cuidado específico: Não repinte digitalmente, remova falhas ou ajuste iluminação do depois para aparentar cobertura e acabamento que não existem.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se explicar preparação ou aplicação, use rótulos na região citada e mantenha o gesto observável; não corte etapas relevantes para fazer a execução parecer mais rápida ou simples.

- Quando apresentar sequência, use cartões apenas com as fases narradas e identifique intervalos na gravação; não invente demãos, tempo de secagem ou materiais para completar uma receita visual.

- Se comparar acabamento, mantenha enquadramento e luz equivalentes e destaque o detalhe real; uma divisão em cartões ou janela pode ajudar, sem recolorir a parede nem remover marcas por edição.

Confira materiais, unidades e condições fornecidas. Não invente rendimento, cobertura, durabilidade ou compatibilidade; preserve cor e defeitos reais, diferenciando uma amostra de cor de prova sobre como ficará toda a superfície.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 151 · Instalador de energia solar

**Área:** Imóveis, construção e decoração

**Preset recomendado:** Componente solar e registro contextual · AEIA-151

**Para que serve:** Editar apresentações e explicações de sistemas solares relacionando componentes e registros reais, distinguindo esquema didático, instalação documentada e medições fornecidas sem criar validação técnica ou desempenho presumido.

**Antes de gravar:** Filme componentes e identificações autorizadas sem interferir na instalação. Forneça desenhos e capturas de medições mencionadas, ocultando dados de clientes, localização privada e acessos ao sistema de monitoramento antes da gravação.

**Ideia para testar:** Apresente componentes visíveis autorizados e uma captura de monitoramento fornecida, sem intervir na instalação ou inferir desempenho.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Instalador de energia solar**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Componente solar e registro contextual (AEIA-151)**

- Identidade: pessoa e interface + tipografia didática; base #233039, destaque #B5CEDB, texto #FFFFFF.
- Ênfases: par humanista-fino. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Mantenha nomes de componentes, unidades e condições em frases estáveis, fora de conexões e medições; preserve a distinção entre explicação, instalação registrada e desempenho efetivamente documentado.
- Ritmo: Siga a função e a relação entre componentes conforme narradas, dando tempo para ler medições fornecidas; não antecipe resultados nem corte condições necessárias para interpretar o registro.
- Motivo visual: Componentes reais identificados com rótulos e relações funcionais narradas, mantendo instalação, esquema didático e medição documentada separados sem presumir dimensionamento técnico do sistema.
- Recursos disponíveis para esta direção: checklist sincronizado aos itens narrados (listas); vídeo em janela, com fundo coberto (recuo).
- Cena temática (composição sobre material fornecido): Quando o instalador explicar um componente ou relação do sistema, use os registros correspondentes e as informações fornecidas, sem acrescentar conexões, dimensionamento ou validação técnica. Mostre a instalação em contexto, destaque o componente citado e conecte sua função por rótulo simples; caso haja medição fornecida, preserve unidade e período, distinguindo esquema ilustrativo de registro real sem gerar curva de produção ou economia presumida.
- Preserve no enquadramento: Preserve identificação dos componentes, unidade, período e contexto de medições, ocultando dados pessoais e informações sensíveis do cliente.
- 3D: Modelo 3D só com material fornecido e compatível com a instalação explicada; sem ele, use vistas reais ou esquema 2D ilustrativo sem criar projeto elétrico executável.
- Cuidado específico: Não invente ligação, produção, economia ou selo de instalação segura para completar a explicação visual do sistema.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se explicar componentes, use rótulos sobre o registro real e um esquema 2D de conexões narradas; não acrescente cabeamento, proteção ou fluxo técnico para completar uma instalação por suposição.

- Quando mostrar etapas, associe cartões aos registros correspondentes e preserve a execução observável; não omita condições relevantes nem acrescente instruções operacionais que o profissional não apresentou.

- Se comentar monitoramento ou resultados, mostre a captura original em janela e destaque período e unidade informados; gráficos próprios só podem usar dados fornecidos, sem transformar previsão em geração medida.

Confira modelos, medidas e unidades contra os materiais. Não invente potência, geração, economia, retorno ou conformidade; preserve as condições registradas e não apresente diagrama editorial como projeto elétrico ou comprovação de segurança.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```
