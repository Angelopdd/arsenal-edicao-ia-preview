# 02 · Outras profissões da saúde

14 prompts completos com direções próprias.

# 023 · Dentista clínico geral

**Área:** Outras profissões da saúde

**Preset recomendado:** Dente e processo sincronizados · AEIA-023

**Para que serve:** Representar explicações odontológicas acompanhando cada etapa da fala, com imagens do dente e do processo descrito aparecendo no momento pertinente.

**Antes de gravar:** Explique uma dúvida e suas etapas em sequência, nomeando as estruturas que deseja mostrar. Se demonstrar em modelo ou boca autorizada, grave um detalhe iluminado, estável e sem instrumentos escondendo a ação.

**Ideia para testar:** Explique em um modelo a organização do dente e destaque as estruturas que você nomear.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Dentista clínico geral**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Dente e processo sincronizados (AEIA-023)**

- Identidade: pessoa e interface + tipografia didática; base #203135, destaque #A7DFD7, texto #FFFFFF.
- Ênfases: par editorial-leve. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Frases estáveis preservam causa, condição e consequência narradas; a legenda ocupa a faixa livre, separada do dente ilustrado e de seus rótulos.
- Ritmo: A primeira imagem surge junto ao primeiro conceito explicável; cada alteração acompanha sua menção, sem aguardar um bloco posterior para ilustrar a introdução.
- Motivo visual: Um dente de referência mantém orientação constante enquanto camadas e etapas narradas são reveladas com rótulos discretos.
- Recursos disponíveis para esta direção: vídeo em janela, com fundo coberto (recuo); reenquadramentos pontuais (planos).
- Cena temática (receita 2D a implementar): Quando o dentista explicar a formação ou a evolução de um processo no dente, com etapas identificáveis na gravação e sem exigir dados ausentes. Apresentar o dente ilustrativo na primeira menção pertinente e revelar cada elemento no momento de sua explicação. Evoluir somente as etapas narradas, mantendo orientação e rótulos; se necessário, abrir um corte separado para mostrar o interior.
- Preserve no enquadramento: Preservar dentes, ferramentas e mãos da demonstração, além das condições que delimitam a explicação clínica do processo.
- 3D: Dente ou vista explodida 3D exige material anatômico fornecido e conferido, com partes correspondentes à fala; sem ele, camadas 2D ilustrativas e rotuladas.
- Cuidado específico: Não atrasar o início do apoio visual, inventar evolução clínica nem mostrar estruturas dentais com posição incorreta.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se o tema explicar um processo, escreva uma cena dental esquemática 2D que evolua por etapas da narração: apresente a estrutura na pergunta e represente a ação ao começar a explicação, sem esperar um bloco posterior.

- Quando explicar camadas ou componentes, use corte 2D com rótulos conferidos e destaque a parte citada. Vista explodida ou anatomia 3D depende de material compatível disponível; sem ele, preserve a explicação com camadas desenhadas.

Confira nomes, posição e sequência contra a fala e referências fornecidas. Não invente mecanismos ou resultados; a cena ilustrativa deve acompanhar cada etapa e permanecer distinguível da demonstração ou do registro real.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 024 · Dentista ortodontista

**Área:** Outras profissões da saúde

**Preset recomendado:** Arcadas em relação · AEIA-024

**Para que serve:** Esclarecer relações entre dentes, arcadas e dispositivos com comparações visuais fiéis, sem apresentar movimentos ilustrativos como previsão individual de tratamento.

**Antes de gravar:** Apresente modelos e dispositivos em uma posição estável, mostrando a vista que deseja explicar. Se comparar registros, identifique suas datas e mantenha disponíveis imagens sem dados pessoais e sem filtros.

**Ideia para testar:** Mostre um modelo de arcadas e explique como apresentar suas diferentes vistas ao público.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Dentista ortodontista**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Arcadas em relação (AEIA-024)**

- Identidade: pessoa e interface + tipografia didática; base #26303A, destaque #BECFE7, texto #FFFFFF.
- Ênfases: par humanista-fino. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Manter termos de posição e limites da comparação legíveis; a ênfase acompanha o nome do dispositivo sem cobrir a arcada ou antecipar resultados.
- Ritmo: Sustentar a vista para reconhecer a relação entre arcadas; mudanças de posição ou dispositivo seguem a explicação, sem acelerar movimentos ilustrativos como tratamento.
- Motivo visual: Referência de arcada fixa e janelas de dispositivo destacam relações espaciais sem transformar desenho em previsão individual de alinhamento.
- Recursos disponíveis para esta direção: reenquadramentos pontuais (planos); vídeo em janela, com fundo coberto (recuo).
- Cena temática (composição sobre material fornecido): Quando o ortodontista explicar uma relação entre dentes, arcadas ou dispositivo, utilizando imagens, modelos ou registros correspondentes que tenham sido fornecidos pelo autor. Mostrar a vista fornecida sem deformação e localizar a região mencionada. Acrescentar setas conceituais apenas para a relação falada, identificando simulações como ilustrativas; sequências documentais mantêm seus próprios momentos e contexto, sem gerar etapas intermediárias.
- Preserve no enquadramento: Preservar orientação da arcada, proporções dos dentes e identificação das fases reais de qualquer registro de tratamento.
- 3D: Usar modelo de arcada ou dispositivo 3D fornecido e conferido para a relação descrita; sem ele, esquema 2D rotulado sem prever deslocamento individual.
- Cuidado específico: Não criar alinhamento automático, estimar duração de tratamento ou fazer um dispositivo atuar de forma anatomicamente impossível.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se a fala abordar posição de dentes ou relação entre arcadas, desenhe vistas esquemáticas 2D consistentes e destaque os elementos citados. Setas representam a relação narrada, sem força, distância ou previsão acrescentadas.

- Quando mostrar aparelho ou alinhador, aproxime os componentes reais e preserve a demonstração de encaixe. Para explicar geometria, use camadas desenhadas; um modelo 3D exige material compatível disponível e não representa planejamento individual inexistente.

Confira lado, arcada, componente e ordem dos registros. Não invente prazo, trajetória de movimentação ou resultado final; as animações devem representar apenas o que o profissional explica e qualifica.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 025 · Dentista implantodontista

**Área:** Outras profissões da saúde

**Preset recomendado:** Componentes do implante · AEIA-025

**Para que serve:** Tornar componentes e etapas explicados em implantodontia visualmente compreensíveis, diferenciando montagem didática, planejamento fornecido e resultado real documentado.

**Antes de gravar:** Grave o modelo por inteiro e depois detalhes dos componentes citados, mantendo a orientação. Se usar imagens de planejamento, retire dados pessoais e indique quais marcações pertencem ao material original.

**Ideia para testar:** Apresente um modelo didático e nomeie os componentes que deseja mostrar em uma vista separada.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Dentista implantodontista**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Componentes do implante (AEIA-025)**

- Identidade: pessoa e interface + tipografia didática; base #273034, destaque #CBD6D8, texto #FFFFFF.
- Ênfases: par humanista-fino. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Frases estáveis acompanham a função atribuída a cada componente; os nomes permanecem próximos às peças, sem a legenda cobrir encaixes ou confundir etapas.
- Ritmo: Revelar uma peça por vez conforme sua menção; sustentar o conjunto ao concluir a relação, sem converter montagem didática em procedimento instantâneo.
- Motivo visual: Peças rotuladas se organizam em uma vista de montagem, diferenciando componentes, planejamento fornecido e etapas narradas pelo profissional.
- Recursos disponíveis para esta direção: vídeo em janela, com fundo coberto (recuo); checklist sincronizado aos itens narrados (listas).
- Cena temática (receita 2D a implementar): Quando o implantodontista nomear componentes ou explicar como se relacionam, com nomenclatura e disposição sustentadas pela fala e pelo material demonstrativo disponível. Apresentar os componentes citados em camadas 2D separadas, identificando a montagem como ilustrativa. Aproximar cada peça apenas ao explicar sua relação; manter os rótulos e distinguir essa cena de qualquer planejamento individual fornecido pelo autor.
- Preserve no enquadramento: Preservar a identificação e a ordem dos componentes, sem cobrir o modelo ou os detalhes de encaixe apresentados.
- 3D: Vista explodida 3D só com material fornecido e conferido compatível com os componentes citados; sem ele, montagem 2D ilustrativa sem especificações técnicas inventadas.
- Cuidado específico: Não inventar peças, posições ósseas, integração biológica ou resultado de implante para completar visualmente a narrativa.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se a explicação identificar componentes, escreva uma montagem esquemática 2D em camadas e rotule cada peça quando citada. Preserve a relação espacial na separação; vista explodida 3D só com material compatível disponível e conferido.

- Quando a fala descrever etapas, apresente uma sequência ilustrativa correspondente sem criar manobras ausentes. Em imagens de planejamento fornecidas, destaque o ponto real com rótulo discreto, sem adicionar volume, encaixe ou resultado idealizado.

Confira identificação dos componentes e distinção entre ilustração e planejamento individual. Não invente medidas, condições anatômicas, prazos ou taxas de sucesso para tornar a apresentação mais persuasiva.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 026 · Dentista odontopediatra

**Área:** Outras profissões da saúde

**Preset recomendado:** Sorriso explicado com cuidado · AEIA-026

**Para que serve:** Editar conteúdos odontopediátricos com apoio visual acolhedor e claro, preservando orientações por contexto e demonstrações feitas pelo profissional.

**Antes de gravar:** Grave uma explicação voltada aos responsáveis e mostre os objetos de frente. Para demonstrações, use modelo ou boneco e mantenha a ação completa visível sem depender da participação de uma criança.

**Ideia para testar:** Apresente um modelo e os objetos que utiliza para explicar o atendimento aos responsáveis.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Dentista odontopediatra**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Sorriso explicado com cuidado (AEIA-026)**

- Identidade: pessoa e interface + tipografia didática; base #28332D, destaque #D8E4AE, texto #FFFFFF.
- Ênfases: par editorial-leve. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Frases acolhedoras e claras preservam o contexto da orientação; usar termos completos e destaque moderado, mantendo livres a escova, o modelo e as mãos.
- Ritmo: Acompanhar a demonstração com calma suficiente para reconhecer o gesto; a etapa gráfica começa com a fala correspondente, sem brincadeiras que desviem do ensino.
- Motivo visual: Cartões de etapa e setas suaves acompanham um modelo dental real, com ilustração acolhedora sem personagens assustadores.
- Recursos disponíveis para esta direção: checklist sincronizado aos itens narrados (listas); reenquadramentos pontuais (planos).
- Cena temática (destaque da demonstração real): Quando o odontopediatra demonstrar um cuidado no modelo ou explicar uma sequência com condições narradas, sem precisar expor uma criança para ilustrar a orientação. Preservar o gesto no modelo e identificar a etapa quando mencionada. Acrescentar uma seta de direção somente onde a demonstração sustentar sua posição; se usar desenho separado, identificá-lo como ilustrativo e manter o contexto da orientação.
- Preserve no enquadramento: Preservar mãos, escova, modelo, referências de contexto e a privacidade de crianças em qualquer imagem fornecida pelo autor.
- 3D: Modelo dental 3D fornecido e conferido pode esclarecer uma região não visível; sem ele, esquema 2D ilustrativo, mantendo a demonstração real como apoio principal.
- Cuidado específico: Não usar monstros de cárie, ameaças visuais ou idades presumidas para reforçar uma orientação que exige contexto.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se o tema envolver dentes ou etapas de um processo, desenhe estruturas simples e conferidas com aparência acolhedora. Personagens podem apoiar o tom, mas não substituem a representação correta do que a narração explica.

- Quando houver demonstração em modelo, acompanhe o gesto com setas e aproximações discretas, preservando a ordem narrada. Diferencie orientações por idade somente quando os intervalos estiverem explicitamente presentes na fala.

Confira se o recurso lúdico não altera anatomia, instrumento ou ação descrita. Não complete orientações com quantidades, idades ou recomendações ausentes, nem transforme uma sequência ilustrada em conduta universal.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 027 · Dentista endodontista

**Área:** Outras profissões da saúde

**Preset recomendado:** Interior dental revelado · AEIA-027

**Para que serve:** Esclarecer estruturas internas e etapas narradas em endodontia com cortes didáticos, preservando a diferença entre modelo e evidência clínica apresentada.

**Antes de gravar:** Grave o modelo dental em orientação constante e nomeie as estruturas internas que pretende explicar. Para radiografias, use cópias sem identificação e indique os detalhes aos quais a narração se refere.

**Ideia para testar:** Mostre em um modelo a diferença visual entre a parte externa e as estruturas internas.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Dentista endodontista**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Interior dental revelado (AEIA-027)**

- Identidade: pessoa e interface + tipografia didática; base #292C36, destaque #CDC8E3, texto #FFFFFF.
- Ênfases: par humanista-fino. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Manter nomes internos e etapas em frases estáveis; separar a legenda da narração dos rótulos no corte dental, preservando diferenças entre modelo e exame.
- Ritmo: Passar da referência externa ao interior apenas na menção correspondente; revelar cada etapa sem saltar relações que a explicação precisa estabelecer no corte.
- Motivo visual: Corte dental identificado revela estruturas internas por camadas, mantendo exame real e modelo didático em molduras distintas.
- Recursos disponíveis para esta direção: vídeo em janela, com fundo coberto (recuo); reenquadramentos pontuais (planos).
- Cena temática (receita 2D a implementar): Quando o endodontista explicar estruturas internas ou uma etapa do cuidado, nomeando as regiões que precisam aparecer para sustentar a compreensão do conteúdo gravado. Partir de um dente ilustrativo orientado e abrir o corte apenas na explicação do interior. Revelar os rótulos citados e a etapa ativa; qualquer radiografia fornecida aparece em quadro separado, sem completar canais ou interpretar achados ausentes.
- Preserve no enquadramento: Preservar nomenclatura interna, orientação dental e detalhes originais de radiografias sem desenhar estruturas como se fossem achados reais.
- 3D: Interior dental 3D requer material fornecido e conferido para a anatomia citada; sem ele, corte 2D ilustrativo sem inventar quantidade ou trajeto de canais.
- Cuidado específico: Não transformar uma radiografia em modelo anatômico presumido nem animar limpeza interna como prova de resultado clínico.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se a fala explicar o interior do dente, desenhe um corte esquemático 2D conferido e revele a região citada sem perder sua posição no conjunto. Rótulos acompanham a estrutura, sem presumir anatomia igual em todos os dentes.

- Quando houver descrição de etapas, faça o esquema evoluir com a narração e identifique-o como ilustração. Radiografias e instrumentos fornecidos permanecem registros separados, sem canais, alterações ou preenchimentos ideais gerados para completar a imagem.

Confira orientação do dente, nomes e relação entre o esquema e a imagem fornecida. Não acrescente diagnóstico, número de canais, prazo ou resultado de tratamento por inferência da edição.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 028 · Nutricionista

**Área:** Outras profissões da saúde

**Preset recomendado:** Alimento em contexto real · AEIA-028

**Para que serve:** Organizar explicações nutricionais com alimentos e informações legíveis, preservando contexto, quantidades narradas e a distinção entre exemplo e orientação individual.

**Antes de gravar:** Enquadre alimentos, utensílios e rótulos de modo que as informações citadas possam ser lidas. Diga quando uma montagem ou quantidade é apenas um exemplo e grave cada etapa sem cobrir a ação.

**Ideia para testar:** Apresente um rótulo e explique como localizar as informações que você deseja comentar.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Nutricionista**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Alimento em contexto real (AEIA-028)**

- Identidade: pessoa e interface + editorial; base #2C3325, destaque #D4DEA8, texto #FFFFFF.
- Ênfases: par grotesca-italico. Legenda: Editorial: blocos discretos integrados à composição. Blocos discretos mantêm contexto e quantidades narradas; a ênfase destaca critérios de comparação, sem transformar ingredientes isolados em rótulos de valor absoluto.
- Ritmo: Sustentar o alimento ou rótulo até a informação ser lida; as comparações aparecem na ordem explicada, mantendo suas bases visíveis antes da conclusão.
- Motivo visual: Recortes de alimentos e janelas de rótulo se organizam por critério narrado, com porções e exemplos identificados.
- Recursos disponíveis para esta direção: vídeo em janela, com fundo coberto (recuo); checklist sincronizado aos itens narrados (listas).
- Cena temática (composição sobre material fornecido): Quando o nutricionista comparar rótulos, ingredientes ou situações alimentares usando materiais fornecidos, com os critérios e o contexto efetivamente presentes na fala do vídeo. Exibir o material real legível e destacar somente o campo ou ingrediente comentado. Colocar comparações lado a lado quando as bases estiverem claras, mantendo unidades e contexto originais; se algo faltar, não completar valores ou construir uma prescrição.
- Preserve no enquadramento: Preservar cor e aspecto dos alimentos, unidades dos rótulos e as condições que distinguem exemplo alimentar de orientação individual.
- 3D: Recorrer a material 3D fornecido e conferido apenas para composição espacial realmente explicada; sem ele, alimento real ou recorte 2D, sem corpos transformados.
- Cuidado específico: Não inventar calorias, porções ou efeitos corporais nem marcar alimentos como proibidos pela escolha de cor.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se houver montagem de prato ou preparação, mostre a execução real e identifique os itens à medida que forem citados. Evite alterar tamanho de porções ou substituir ingredientes por imagens visualmente mais atraentes.

- Quando comparar rótulos ou valores fornecidos, use uma tabela com porção e unidade visíveis. Não atribua classificações de melhor e pior por cores quando a profissional apresentou diferenças contextuais.

Confira ingredientes, quantidades, unidades e equivalência das comparações. Não calcule ou invente valores nutricionais, substituições, metas ou restrições sem dados e instruções expressamente presentes no material fornecido. Compare porções realmente equivalentes no material.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 029 · Psicólogo

**Área:** Outras profissões da saúde

**Preset recomendado:** Relações sem rótulos · AEIA-029

**Para que serve:** Dar clareza a reflexões e explicações psicológicas com organização conceitual acolhedora, preservando nuances e evitando diagnósticos sugeridos pela montagem.

**Antes de gravar:** Grave a ideia principal com pausas naturais e identifique exemplos como hipotéticos quando for o caso. Para relatos, prepare uma versão sem detalhes que permitam reconhecer pessoas ou contextos específicos.

**Ideia para testar:** Explique como você diferencia uma informação educativa de uma avaliação individual no seu conteúdo.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Psicólogo**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Relações sem rótulos (AEIA-029)**

- Identidade: pessoa e interface + editorial; base #302C2A, destaque #DCC7BA, texto #FFFFFF.
- Ênfases: par editorial-leve. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Frases estáveis preservam nuance e acolhimento; a ênfase pontua uma ideia completa, sem destacar características isoladas que pareçam um diagnóstico de quem assiste.
- Ritmo: Manter pausas com função reflexiva e o tempo de compreender relações; os apoios entram discretamente, sem interromper o vínculo visual com o profissional.
- Motivo visual: Cartões relacionais e espaços de contexto representam ideias da fala, sem rostos estereotipados ou classificação visual de pessoas.
- Recursos disponíveis para esta direção: reenquadramentos pontuais (planos); vídeo em janela, com fundo coberto (recuo).
- Cena temática (receita 2D a implementar): Quando o psicólogo relacionar situações, pensamentos ou experiências explicitamente descritos, sem exigir que a edição crie uma avaliação psicológica ou um exemplo clínico novo. Apresentar os elementos citados em cartões de mesma dignidade e revelar as conexões quando explicadas. Manter condições junto às relações; se a fala usar metáfora, identificá-la como tal e não converter a cena em teste do espectador.
- Preserve no enquadramento: Preservar negações, pausas reflexivas, linguagem não estigmatizante e a confidencialidade de qualquer relato pessoal apresentado no conteúdo.
- 3D: Não inserir anatomia 3D em reflexões sem motivo; se uma relação espacial for realmente explicada, exigir material fornecido e conferido, com alternativa 2D ilustrativa.
- Cuidado específico: Não associar uma reação isolada a transtorno, ilustrar relatos com estereótipos ou apresentar cura por transformação gráfica.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se a fala distinguir pensamentos, emoções e comportamentos, use um diagrama com as relações realmente descritas. Não imponha uma cadeia causal única nem transforme exemplos em um checklist para o espectador se diagnosticar.

- Quando houver metáfora ou exercício explicado, use formas e palavras discretas que acompanhem o raciocínio. Preserve pausas de reflexão e não acrescente contagens, instruções ou etapas que a profissional não forneceu.

Confira se hipótese, exemplo e experiência pessoal continuam identificáveis. Nenhuma legenda ou composição deve rotular pessoas, atribuir intenção ou prometer um efeito terapêutico não afirmado pelo profissional.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 030 · Neuropsicólogo

**Área:** Outras profissões da saúde

**Preset recomendado:** Funções em tarefa contextual · AEIA-030

**Para que serve:** Apresentar conceitos e etapas da neuropsicologia de forma compreensível, distinguindo domínios, tarefas ilustrativas e resultados de avaliação efetivamente fornecidos.

**Antes de gravar:** Use materiais demonstrativos preparados para divulgação, sem expor testes ou protocolos restritos. Ao apresentar uma sequência de avaliação, diga qual etapa está explicando e remova dados pessoais dos exemplos.

**Ideia para testar:** Explique as etapas gerais de uma avaliação sem mostrar itens de testes ou resultados pessoais.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Neuropsicólogo**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Funções em tarefa contextual (AEIA-030)**

- Identidade: pessoa e interface + tipografia didática; base #2A2D37, destaque #C4CCE3, texto #FFFFFF.
- Ênfases: par humanista-fino. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Blocos estáveis mantêm limites e relações entre funções; identificar tarefas ilustrativas sem usar ênfase que faça uma dificuldade parecer diagnóstico ou resultado de avaliação.
- Ritmo: Mostrar o contexto antes da tarefa e sustentar sua sequência explicada; a montagem não acelera respostas nem retira etapas que mudariam a interpretação.
- Motivo visual: Mapa de domínios relacionados acompanha uma tarefa ilustrativa identificada, mantendo função, processo de avaliação e resultado em níveis separados.
- Recursos disponíveis para esta direção: checklist sincronizado aos itens narrados (listas); vídeo em janela, com fundo coberto (recuo).
- Cena temática (receita 2D a implementar): Quando o neuropsicólogo explicar como funções participam de uma atividade ou diferenciar etapas de avaliação, com exemplos explicitamente autorizados e descritos no conteúdo gravado. Abrir cartões para as funções nomeadas e relacioná-los à atividade citada, sem atribuir escores. Se houver demonstração de tarefa ilustrativa permitida, identificá-la e preservar a sequência; resultados reais fornecidos permanecem separados e contextualizados.
- Preserve no enquadramento: Preservar contexto, limites da avaliação e sigilo de resultados, sem expor protocolos ou materiais de teste restritos.
- 3D: Cérebro 3D só com material fornecido e conferido para anatomia realmente narrada; sem ele, mapa conceitual 2D, sem localizar funções de forma presumida.
- Cuidado específico: Não fabricar pontuações, reproduzir testes restritos ou reduzir um domínio cognitivo a uma única área cerebral decorativa.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se o tema comparar funções cognitivas, organize os conceitos em blocos relacionados conforme a narração. Não represente cada função como um ponto cerebral isolado que determine, sozinho, um comportamento.

- Quando explicar uma tarefa ilustrativa, destaque a instrução e a ação visível na ordem apresentada, identificando o caráter demonstrativo. Não reproduza itens, respostas ou critérios restritos para preencher lacunas de imagem.

Confira se nenhuma pontuação, classificação ou associação anatômica foi criada pela edição. Preserve sigilo dos materiais e não transforme desempenho em tarefa ilustrativa em conclusão sobre capacidade ou condição clínica.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 031 · Fisioterapeuta

**Área:** Outras profissões da saúde

**Preset recomendado:** Gesto terapêutico legível · AEIA-031

**Para que serve:** Valorizar demonstrações e explicações fisioterapêuticas preservando movimentos completos, referências corporais e condições narradas, sem criar correções ou medições artificiais.

**Antes de gravar:** Posicione a câmera para mostrar o segmento corporal inteiro e os apoios utilizados. Grave uma execução contínua antes dos detalhes e identifique verbalmente o lado e a etapa quando isso importar.

**Ideia para testar:** Demonstre um gesto escolhido por você e explique quais partes precisam permanecer visíveis no vídeo.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Fisioterapeuta**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Gesto terapêutico legível (AEIA-031)**

- Identidade: pessoa e interface + tipografia didática; base #26322D, destaque #BDDCCB, texto #FFFFFF.
- Ênfases: par editorial-leve. Legenda: Padrão do kit, com tratamento conferido para este vídeo. Legenda curta fora da articulação ou apoio demonstrado; preservar as condições de execução na sequência, evitando ênfases que cubram mãos e referências corporais.
- Ritmo: Manter cada movimento completo, incluindo preparação e retorno quando necessários; cortar a fala entre demonstrações, sem simular fluidez ou amplitude que não foram registradas.
- Motivo visual: Fases nomeadas e linhas direcionais discretas acompanham o gesto real, com esquema funcional separado apenas para relações não visíveis.
- Recursos disponíveis para esta direção: reenquadramentos pontuais (planos); vídeo em janela, com fundo coberto (recuo).
- Cena temática (destaque da demonstração real): Quando o fisioterapeuta demonstrar um movimento ou comparar posições com condições claras na narração, e a região relevante estiver efetivamente visível na gravação. Preservar o ciclo demonstrado e nomear a fase quando explicada. Acrescentar linhas apenas para direção ou referência ilustrativa, sem medir automaticamente; se comparar posições, manter orientação, apoio e contexto de cada tomada identificados.
- Preserve no enquadramento: Preservar articulações, mãos, apoios e fases completas do gesto, inclusive as condições individuais mencionadas durante a demonstração.
- 3D: Anatomia funcional 3D exige material fornecido e conferido para a relação narrada; sem ele, esquema 2D ilustrativo sem reconstruir articulações ocultas ou medir ângulos.
- Cuidado específico: Não corrigir postura digitalmente, inventar alinhamento clínico ou acelerar repetições para sugerir melhora funcional inexistente.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se houver demonstração, mostre primeiro o movimento completo e depois destaque a fase citada com linhas discretas ou repetição identificada. Preserve o tempo necessário para observar transições e posições de apoio.

- Quando a explicação envolver anatomia ou mecanismo, desenhe um esquema 2D rotulado ao lado do gesto ou em inserção breve. Não sobreponha anatomia genérica como se fosse análise biomecânica precisa da pessoa filmada.

Confira lado, sequência, apoio e orientação das setas. Não acrescente repetições, carga, amplitude ou recomendação de exercício, nem transforme uma linha desenhada em medida clínica ou prova de correção.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 032 · Fonoaudiólogo

**Área:** Outras profissões da saúde

**Preset recomendado:** Voz e articulação preservadas · AEIA-032

**Para que serve:** Preservar exemplos de voz, fala e demonstração oral com apoios visuais pertinentes, sem alterar as características que o profissional precisa apresentar.

**Antes de gravar:** Use um ambiente silencioso e mantenha distância constante do microfone nos exemplos comparáveis. Se demonstrar articulação, enquadre rosto e boca com luz frontal e grave a ação completa sem cortes.

**Ideia para testar:** Grave exemplos sonoros escolhidos por você e explique quais diferenças deseja tornar perceptíveis.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Fonoaudiólogo**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Voz e articulação preservadas (AEIA-032)**

- Identidade: pessoa e interface + tipografia didática; base #2D2B34, destaque #D4C6DE, texto #FFFFFF.
- Ênfases: par humanista-fino. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Blocos estáveis distinguem explicação e exemplo sonoro; grafar fielmente a produção demonstrada sem normalizar pronúncia, mantendo livre a boca quando a articulação importar.
- Ritmo: Preservar a duração dos exemplos vocais e intervalos que fazem parte da demonstração; a edição da fala explicativa não altera a produção usada como exemplo.
- Motivo visual: Janela oral e marcação temporal de exemplos conectam som real, gesto articulatório visível e esquema didático separado.
- Recursos disponíveis para esta direção: vídeo em janela, com fundo coberto (recuo); reenquadramentos pontuais (planos).
- Cena temática (destaque da demonstração real): Quando o fonoaudiólogo demonstrar uma articulação ou comparar produções sonoras, deixando explícito qual característica precisa ser observada e ouvida no exemplo apresentado pelo profissional. Manter o exemplo completo com boca e gesto visíveis; identificar cada produção na hora correspondente. Se usar visualização do áudio real fornecido, rotulá-la sem valores clínicos inferidos e separar qualquer esquema oral identificado como ilustrativo.
- Preserve no enquadramento: Preservar boca, língua quando visível, respiração didática e características sonoras que sustentam o exemplo, sem tratamento que as apague.
- 3D: Articulação oral 3D só com material fornecido e conferido correspondente ao som explicado; sem ele, esquema 2D ilustrativo sem inferir movimentos internos ocultos.
- Cuidado específico: Não remover sopros didáticos, corrigir a voz, sincronizar uma boca artificial ou inventar análise acústica clínica.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se a fala mostrar articulação, mantenha a boca visível e escreva um esquema 2D simples apenas quando ajudar a localizar o ponto explicado. Não substitua o gesto real por uma boca animada sem correspondência.

- Quando comparar sons, preserve o exemplo inteiro e identifique cada amostra. Se desenhar uma onda a partir do áudio, trate-a como visualização ilustrativa sem interpretação clínica; não sobreponha sons, legenda invasiva ou efeitos ao detalhe demonstrado.

Confira articulação, duração e timbre dos exemplos. Preserve o áudio demonstrativo original, suspendendo cortes de respiro ou processamento que alterem o fenômeno; valide a cadeia de voz/mono antes de usá-la e não invente medidas acústicas.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 033 · Enfermeiro

**Área:** Outras profissões da saúde

**Preset recomendado:** Etapas observáveis do cuidado · AEIA-033

**Para que serve:** Organizar demonstrações e orientações de enfermagem com etapas observáveis, mantendo a sequência técnica narrada e a identificação correta dos materiais apresentados.

**Antes de gravar:** Prepare uma bancada de demonstração sem dados de pacientes e mantenha materiais identificáveis. Grave as mãos e o campo completo em tomada contínua, nomeando cada troca de instrumento ou etapa importante.

**Ideia para testar:** Apresente uma bancada didática e explique como você organiza os materiais antes de uma demonstração.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Enfermeiro**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Etapas observáveis do cuidado (AEIA-033)**

- Identidade: pessoa e interface + tipografia didática; base #24342F, destaque #B9DECF, texto #FFFFFF.
- Ênfases: par editorial-leve. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Blocos claros preservam a condição e a ação narradas; posicionar a legenda fora das mãos e materiais, com os nomes técnicos legíveis e completos.
- Ritmo: Manter a ordem e a continuidade das etapas demonstradas; transições ocorrem entre ações concluídas, sem esconder preparações relevantes ou simular um procedimento abreviado.
- Motivo visual: Etiquetas de material e lista progressiva acompanham a etapa real, sem marcar como concluída uma ação ainda não mostrada.
- Recursos disponíveis para esta direção: checklist sincronizado aos itens narrados (listas); reenquadramentos pontuais (planos).
- Cena temática (destaque da demonstração real): Quando o enfermeiro demonstrar uma sequência de cuidado ou apresentar materiais, com ações e condições descritas na fala e observáveis no registro original fornecido. Identificar os materiais somente quando apresentados e revelar a etapa junto à ação narrada. Manter os gestos necessários completos; usar a lista para orientar a sequência, sem acrescentar técnica, ordem ou conclusão que não estejam registradas.
- Preserve no enquadramento: Preservar mãos, pontos de contato, identificação de materiais e contexto da demonstração, mantendo dados de atendimento fora da tela.
- 3D: Só usar dispositivo ou anatomia 3D fornecidos e conferidos para detalhe espacial explicado; sem isso, demonstração real ou esquema 2D identificado, sem técnica inventada.
- Cuidado específico: Não pular etapas técnicas para ganhar ritmo, trocar materiais por similares nem criar dosagem ou orientação de procedimento.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se houver procedimento demonstrado em modelo ou ambiente educativo, mostre a sequência real e destaque a ação em execução, sem pular uma etapa apenas para acelerar o ritmo da montagem.

- Quando apresentar materiais, associe as etiquetas ao objeto correto e deixe o texto fora do campo de ação. Uma montagem em camadas pode organizar os itens, sem sugerir que todos são necessários em qualquer situação.

Confira nomes dos materiais, ordem dos gestos e condições que limitam a orientação. Não complete etapas clínicas, volumes, tempos ou recomendações ausentes e não use animação para encobrir uma ação não registrada.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 034 · Farmacêutico

**Área:** Outras profissões da saúde

**Preset recomendado:** Informação de embalagem em foco · AEIA-034

**Para que serve:** Tornar explicações farmacêuticas legíveis e contextualizadas, destacando embalagens e informações fornecidas sem criar instruções de uso, equivalência ou dosagem.

**Antes de gravar:** Mostre embalagens, materiais ou documentos de frente e sem reflexos, retirando dados pessoais. Pronuncie claramente nomes e unidades que precisam aparecer e indique quando uma informação é apenas um exemplo.

**Ideia para testar:** Explique como localizar informações em uma embalagem preparada para demonstração, sem orientar um tratamento.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Farmacêutico**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Informação de embalagem em foco (AEIA-034)**

- Identidade: pessoa e interface + tipografia didática; base #27332C, destaque #C5DDBA, texto #FFFFFF.
- Ênfases: par humanista-fino. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Frases estáveis preservam restrições e condições; a ênfase destaca o campo explicado, sem ampliar um produto como recomendação nem cobrir informação original da embalagem.
- Ritmo: Dar tempo para localizar e ler o campo destacado antes de mudar; comparações mantêm seus contextos visíveis e não antecipam equivalência ou conclusão.
- Motivo visual: Janelas de embalagem e rótulos de campo diferenciam informação impressa, explicação do profissional e comparação conceitual contextualizada.
- Recursos disponíveis para esta direção: vídeo em janela, com fundo coberto (recuo); checklist sincronizado aos itens narrados (listas).
- Cena temática (composição sobre material fornecido): Quando o farmacêutico explicar um campo da embalagem ou um dispositivo fornecido, nomeando a informação que deve ser observada sem exigir completar orientações de uso. Ampliar o campo real e marcar sua localização com contorno discreto. Revelar somente a informação citada, mantendo o contexto impresso e a narração; se comparar conceitos, usar cartões separados sem criar equivalência, indicação ou dosagem.
- Preserve no enquadramento: Preservar grafia, unidades, informações originais e condições narradas, sem expor identificação de pacientes ou prescrições pessoais.
- 3D: Dispositivo 3D pode esclarecer uma peça apenas se fornecido e conferido para o modelo citado; sem ele, detalhe real ou esquema 2D ilustrativo.
- Cuidado específico: Não gerar embalagens convincentes com texto falso, completar doses ou sugerir intercambialidade pela semelhança entre cartões.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se o tema envolver leitura de embalagem ou documento, amplie apenas a informação mencionada e mantenha sua relação com o material original. Não recrie uma embalagem com números ou elementos inventados.

- Quando explicar diferenças conceituais, use cartões ou fluxo com os critérios narrados. Evite cores e símbolos que sugiram intercambialidade, superioridade ou indicação universal que o profissional não estabeleceu.

Confira grafia de produtos, unidades e qualificadores com o material. Não acrescente doses, horários, substituições ou alertas por conta própria e não apresente um exemplo educativo como prescrição individual. Preserve a identificação exata dos produtos.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 035 · Biomédico

**Área:** Outras profissões da saúde

**Preset recomendado:** Amostra ao processo narrado · AEIA-035

**Para que serve:** Editar conteúdos biomédicos conforme a atuação apresentada, tornando amostras, equipamentos e processos legíveis sem extrapolar atribuições ou resultados do registro.

**Antes de gravar:** Diga na abertura qual área de atuação está explicando e enquadre os materiais utilizados. Para telas, amostras ou registros, retire identificações e capture detalhes estáveis do que será comentado.

**Ideia para testar:** Apresente um equipamento ou material da sua atuação e explique seus elementos visíveis ao público.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Biomédico**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Amostra ao processo narrado (AEIA-035)**

- Identidade: pessoa e interface + tipografia didática; base #263137, destaque #B7D9DC, texto #FFFFFF.
- Ênfases: par humanista-fino. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Blocos técnicos legíveis acompanham a atuação apresentada; preservar nomes de amostras, equipamentos e limites, sem destacar um resultado fora de seu contexto original.
- Ritmo: Separar apresentação do material, etapa narrada e eventual resultado; mudanças de escala são identificadas e não substituem a observação real por animação genérica.
- Motivo visual: Percurso de amostra com cartões de etapa mantém separados registro laboratorial, detalhe de equipamento e ilustração em outra escala.
- Recursos disponíveis para esta direção: checklist sincronizado aos itens narrados (listas); vídeo em janela, com fundo coberto (recuo).
- Cena temática (receita 2D a implementar): Quando o biomédico explicar um processo de sua atuação apresentada, com amostra, equipamento ou etapas claramente identificados na gravação ou nos arquivos do autor. Apresentar os elementos citados e ligar as etapas apenas quando narradas. Usar imagens reais fornecidas com identificação; se houver mudança de escala ilustrativa, sinalizá-la e não transformar um desenho de amostra em resultado de exame.
- Preserve no enquadramento: Preservar a atuação efetivamente apresentada, identificações técnicas dos materiais e o sigilo de resultados ou dados pessoais de amostras.
- 3D: Equipamento ou estrutura microscópica 3D exige material fornecido e conferido para o tema; sem ele, fluxo 2D ilustrativo sem morfologia ou resultado inventados.
- Cuidado específico: Não extrapolar a atuação narrada, fabricar lâminas ou laudos nem usar tubos genéricos como evidência de procedimento.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se o vídeo explicar uma rotina laboratorial, organize amostra, preparação, equipamento e leitura somente na sequência narrada. Identifique representações geradas como ilustrações, sem fazê-las parecer micrografias ou resultados reais.

- Quando demonstrar aparelho ou material, priorize o registro original com rótulos junto às partes citadas. Não insira efeitos luminosos para sugerir ação biológica, precisão ou benefício não demonstrado.

Confira a atuação declarada, origem das imagens e correspondência entre etapa e resultado. Não invente laudos, achados, habilitações ou efeitos, nem use uma animação como comprovação de eficácia ou conclusão clínica. Identifique a natureza das amostras.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 036 · Terapeuta ocupacional

**Área:** Outras profissões da saúde

**Preset recomendado:** Atividade e adaptação visíveis · AEIA-036

**Para que serve:** Valorizar atividades, adaptações e contextos explicados pela terapia ocupacional, preservando autonomia e sequência real sem fabricar desempenho ou generalizar soluções individuais.

**Antes de gravar:** Enquadre a atividade inteira com objetos e apoios visíveis antes de gravar detalhes. Explique o objetivo do exemplo e use uma demonstração preparada sem expor rotinas ou dados pessoais de atendidos.

**Ideia para testar:** Demonstre a organização de uma tarefa cotidiana e explique os aspectos que deseja tornar visíveis.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Terapeuta ocupacional**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Atividade e adaptação visíveis (AEIA-036)**

- Identidade: pessoa e interface + editorial; base #303129, destaque #D8D9B6, texto #FFFFFF.
- Ênfases: par editorial-leve. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Frases estáveis valorizam atividade, contexto e escolha; a legenda fica fora das mãos e objetos, sem classificar o desempenho da pessoa por adjetivos isolados.
- Ritmo: Respeitar o tempo da atividade e a sequência de uso do recurso; retirar repetições de fala sem fabricar facilidade, independência ou velocidade de execução.
- Motivo visual: Tríade pessoa, atividade e contexto organiza detalhes de adaptação, mantendo o objeto real e a autonomia como referências centrais.
- Recursos disponíveis para esta direção: reenquadramentos pontuais (planos); vídeo em janela, com fundo coberto (recuo).
- Cena temática (destaque da demonstração real): Quando o terapeuta ocupacional demonstrar uma atividade ou explicar uma adaptação em seu contexto, com o uso real do objeto suficientemente visível no registro fornecido. Preservar a sequência de uso e identificar o detalhe comentado sem cobrir a ação. Se comparar configurações, nomeá-las pelo contexto narrado e manter suas condições, sem transformar a adaptação individual em solução universal ou melhoria fabricada.
- Preserve no enquadramento: Preservar mãos, objeto, apoios, escolha e tempo real de execução, sem expor informações pessoais desnecessárias de participantes.
- 3D: Objeto adaptado em 3D só se fornecido e conferido para a relação espacial explicada; sem ele, demonstração ou esquema 2D ilustrativo, sem projeto funcional presumido.
- Cuidado específico: Não acelerar a atividade para provar autonomia nem representar uma adaptação contextual como solução garantida para todos.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se houver demonstração de atividade cotidiana, mantenha a ordem e o tempo de execução necessários para compreender a ação. Destaque o ponto indicado sem esconder mãos, apoios ou interação com o ambiente.

- Quando comparar uma organização ou adaptação, mostre as diferenças reais com etiquetas e enquadramento coerente. Não transforme o recurso demonstrado em solução universal nem gere uma melhora funcional ausente do registro.

Confira se cada apoio visual corresponde ao objetivo e ao contexto narrados. Não altere digitalmente velocidade, alcance ou autonomia para sugerir desempenho superior, nem acrescente indicação de recurso não mencionada.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```
