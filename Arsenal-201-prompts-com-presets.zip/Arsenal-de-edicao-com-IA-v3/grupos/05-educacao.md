# 05 · Educação

12 prompts completos com direções próprias.

# 058 · Professor de português

**Área:** Educação

**Preset recomendado:** Frase em transformação comentada · AEIA-058

**Para que serve:** Transformar explicações de língua portuguesa em sequências visuais legíveis, preservando os exemplos, as distinções e as transformações textuais apresentadas pelo professor.

**Antes de gravar:** Apresente o texto ou a frase de referência em arquivo legível e leia os trechos que serão comentados. Diga quando estiver mostrando uma variante, uma correção ou um exemplo deliberadamente inadequado.

**Ideia para testar:** Explique uma frase escolhida por você e destaque duas alterações textuais que deseja comparar.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Professor de português**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Frase em transformação comentada (AEIA-058)**

- Identidade: pessoa e interface + tipografia didática + editorial; base #302D2A, destaque #DED1B6, texto #FFFFFF.
- Ênfases: par grotesca-italico. Legenda: Editorial: blocos discretos integrados à composição. Distinguir legenda da narração e frase de estudo; blocos discretos preservam acentos, pontuação e negações, sem colorir palavras que ainda não foram analisadas.
- Ritmo: Sustentar o exemplo enquanto a relação é explicada e transformar só o trecho comentado; não apagar a versão anterior antes de concluir a comparação.
- Motivo visual: Frase de estudo com marcações progressivas e versões alinhadas torna visíveis relações sintáticas, escolhas de escrita e mudanças narradas pelo professor.
- Recursos disponíveis para esta direção: vídeo em janela, com fundo coberto (recuo); checklist sincronizado aos itens narrados (listas).
- Cena temática (receita 2D a implementar): Quando o professor de português analisar ou transformar um exemplo escrito que esteja na fala ou no material fornecido, com a distinção que pretende ensinar claramente indicada. Apresentar a frase original fielmente e destacar o trecho no momento da análise. Se houver transformação, manter as versões alinhadas e modificar somente o que o professor explicar, preservando pontuação e sem gerar uma regra ou correção nova.
- Preserve no enquadramento: Preservar grafia, acentos, pontuação, contexto do exemplo e espaço suficiente para ler a frase completa sem competição com legendas.
- 3D: Dispensar letras 3D que prejudiquem leitura; se houver objeto espacial fornecido e conferido pertinente ao exemplo, usá-lo pontualmente, mantendo a frase em 2D legível.
- Cuidado específico: Não corrigir silenciosamente o exemplo de erro, inventar classificação gramatical ou destacar a resposta antes da explicação do professor.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se a explicação analisar uma frase, mantenha o enunciado inteiro disponível e destaque o termo mencionado com cor ou sublinhado. Use cores consistentes, sem transformar todo o texto em legenda que desaparece rapidamente.

- Quando houver alteração de construção ou pontuação, mostre a transformação passo a passo com os exemplos fornecidos. Preserve a forma inicial até que o professor conclua a comparação e explicite a mudança.

Confira acentos, pontuação, aspas e exemplos contra o material. Não corrija silenciosamente um erro intencional usado na aula, nem crie regra ou exceção que o professor não apresentou.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 059 · Professor de matemática

**Área:** Educação

**Preset recomendado:** Raciocínio em linhas preservadas · AEIA-059

**Para que serve:** Apresentar raciocínios matemáticos em etapas visuais verificáveis, preservando notação, hipóteses e encadeamento sem pular operações que sustentam a explicação.

**Antes de gravar:** Forneça o enunciado e a resolução escritos de forma legível, além da gravação. Nomeie cada passagem importante e deixe uma pausa curta quando mudar de linha, expressão, gráfico ou figura.

**Ideia para testar:** Resolva um exercício autoral curto, fornecendo enunciado e cada passagem escrita para conferir na edição.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Professor de matemática**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Raciocínio em linhas preservadas (AEIA-059)**

- Identidade: pessoa e interface + tipografia didática; base #26303A, destaque #C3D7E8, texto #FFFFFF.
- Ênfases: par humanista-fino. Legenda: Editorial: blocos discretos integrados à composição. Blocos discretos narram o raciocínio fora da equação; preservar sinais, hipóteses e nomes matemáticos, sem transformar símbolos em palavras ou ocultar etapas com ênfase.
- Ritmo: A operação fica visível quando mencionada e o destaque acompanha a justificativa; dar tempo de leitura, mantendo as linhas anteriores necessárias ao raciocínio.
- Motivo visual: Linhas de resolução alinhadas e realce de termos acompanham transformações justificadas, com gráfico ou figura apenas quando participam do raciocínio narrado.
- Recursos disponíveis para esta direção: vídeo em janela, com fundo coberto (recuo); checklist sincronizado aos itens narrados (listas).
- Cena temática (receita 2D a implementar): Quando o professor de matemática resolver uma expressão, construir uma figura ou explicar uma relação, com a notação e as etapas sustentadas pela gravação ou material fornecido. Reproduzir o enunciado e as hipóteses citadas, revelando cada linha na ordem da explicação. Realçar o termo operado sem alterar sinais; manter a linha anterior quando necessária e não calcular, completar ou corrigir resultados sem confirmação do professor.
- Preserve no enquadramento: Preservar notação, hipóteses, eixos e linhas necessárias à resolução, mantendo o quadro didático separado da legenda da fala.
- 3D: Geometria espacial 3D só com material fornecido e conferido correspondente ao problema; sem ele, vistas 2D rotuladas sem medidas ou relações espaciais inventadas.
- Cuidado específico: Não pular operação intermediária, perder sinal ou expoente, alterar escala de gráfico nem apresentar cálculo gerado como conteúdo do professor.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se houver resolução, revele uma passagem por vez e mantenha referências às linhas anteriores. Destaque a operação explicada sem fazer símbolos mudarem antes de a narração justificar a transformação.

- Quando o tema envolver geometria ou gráfico, use construção progressiva com eixos, unidades e rótulos fornecidos. Não estime coordenadas, medidas ou proporções para preencher um desenho que exige precisão.

Confira sinais, expoentes, frações, domínios e resultado com a resolução fornecida. Se identificar inconsistência material, sinalize-a sem inventar uma correção; uma animação não pode esconder um salto lógico. Confira também os limites dos eixos.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 060 · Professor de inglês

**Área:** Educação

**Preset recomendado:** Inglês escrito e ouvido · AEIA-060

**Para que serve:** Dar clareza a aulas de inglês preservando exemplos sonoros e escritos, com destaques que acompanhem a explicação sem substituir automaticamente o idioma ensinado.

**Antes de gravar:** Grave os exemplos de fala em ambiente silencioso e forneça suas formas escritas. Identifique se deseja comparar pronúncia, significado ou estrutura, dizendo quando uma frase é um exemplo intencionalmente inadequado.

**Ideia para testar:** Compare duas frases escolhidas por você e forneça a escrita exata de cada exemplo.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Professor de inglês**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Inglês escrito e ouvido (AEIA-060)**

- Identidade: pessoa e interface + tipografia didática; base #27313A, destaque #C8D7E6, texto #FFFFFF.
- Ênfases: par editorial-leve. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Separar legenda explicativa e exemplo em inglês; preservar o idioma realmente falado, com blocos estáveis e destaque só no contraste que o professor estiver explicando.
- Ritmo: Preservar cada exemplo sonoro completo e seu intervalo didático; repetição ou comparação acompanha a explicação, sem acelerar pronúncia ou antecipar uma tradução não apresentada.
- Motivo visual: Cartões de frase e turnos de diálogo distinguem exemplo ouvido, explicação em português e contraste linguístico, sem traduzir automaticamente o conteúdo ensinado.
- Recursos disponíveis para esta direção: vídeo em janela, com fundo coberto (recuo); checklist sincronizado aos itens narrados (listas).
- Cena temática (receita 2D a implementar): Quando o professor de inglês contrastar frases, pronúncias ou usos em contexto, com exemplos escritos e sonoros claramente apresentados na gravação ou nos materiais fornecidos. Exibir o exemplo em inglês junto à sua produção sonora e realçar apenas o trecho comentado. Manter contexto e versões comparadas quando necessários; traduções e símbolos de pronúncia entram somente se o professor os apresentar ou fornecer.
- Preserve no enquadramento: Preservar som, duração, idioma, grafia e contexto de cada exemplo, sem normalizar variantes de pronúncia ou cortar finais usados na explicação.
- 3D: Não usar letras 3D como recurso padrão; objeto fornecido e conferido pode ilustrar vocabulário espacial narrado, com imagem ou esquema 2D identificado como alternativa.
- Cuidado específico: Não traduzir a fala de ensino automaticamente, inventar transcrição fonética nem usar bandeiras como definição de uma pronúncia universal correta.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se a aula comparar pronúncias ou sons, mantenha o exemplo completo e destaque a palavra correspondente. Não altere velocidade, timbre ou entonação de modo que a diferença ensinada deixe de ser audível.

- Quando explicar estrutura, escolha de palavra ou diálogo, mostre as frases fornecidas e destaque o trecho citado. Preserve inglês nos exemplos; tradução e transcrição fonética só entram se fornecidas ou solicitadas, sem preencher sotaques por inferência.

Os transcritores são PT-BR por padrão: confira os trechos em inglês contra áudio e texto fornecido, corrigindo grafia e alinhamento sem traduzir. Preserve erros intencionais e exemplos sonoros originais, suspendendo limpeza que altere pronúncia. Se o PT-BR prejudicar os exemplos no outro idioma, adapte a cópia local da transcrição para um idioma suportado ou alinhe com o texto fornecido. Se não conseguir validar texto e tempos, sinalize o trecho e peça confirmação, sem aprovar uma legenda presumida.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 061 · Professor de espanhol

**Área:** Educação

**Preset recomendado:** Espanhol em contraste contextual · AEIA-061

**Para que serve:** Organizar aulas de espanhol com exemplos escritos e sonoros fiéis, preservando contrastes de significado, pronúncia e contexto apresentados pelo professor.

**Antes de gravar:** Forneça por escrito as frases que serão usadas e grave os exemplos sem ruído de fundo. Diga quando apresentar uma variedade regional, uma tradução ou uma construção usada apenas para comparação.

**Ideia para testar:** Apresente dois exemplos escritos e explique um contraste de uso definido por você.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Professor de espanhol**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Espanhol em contraste contextual (AEIA-061)**

- Identidade: pessoa e interface + tipografia didática; base #332C27, destaque #E3CAAC, texto #FFFFFF.
- Ênfases: par grotesca-italico. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Separar a legenda da explicação e os exemplos em espanhol; manter acentos, contexto e diferenças apresentadas, sem destacar apenas semelhanças que apaguem o sentido ensinado.
- Ritmo: Sustentar cada exemplo sonoro e sua situação de uso; mudanças entre falantes ou contrastes seguem a explicação, sem cortar finais que distinguem as palavras.
- Motivo visual: Frases alinhadas por contexto e turnos identificados tornam claros contrastes de sentido ou uso, preservando a produção sonora real do professor.
- Recursos disponíveis para esta direção: vídeo em janela, com fundo coberto (recuo); checklist sincronizado aos itens narrados (listas).
- Cena temática (receita 2D a implementar): Quando o professor de espanhol comparar usos, sentidos ou pronúncias, com exemplos e contextos presentes na gravação ou nos materiais fornecidos, sem exigir completar uma tradução. Apresentar cada frase com o contexto citado e revelar o contraste na sua explicação. Sincronizar a frase ao exemplo sonoro correspondente; manter traduções e formas alternativas apenas quando fornecidas, sem uniformizar variantes ou inventar um diálogo complementar.
- Preserve no enquadramento: Preservar grafia, acentos, contexto, idioma e duração dos exemplos, incluindo sons finais e variações explicitamente ensinadas pelo professor.
- 3D: Dispensar tipografia 3D durante leitura; objeto fornecido e conferido pode apoiar vocabulário espacial efetivamente narrado, com imagem ou esquema 2D identificado quando faltar material.
- Cuidado específico: Não corrigir variantes para um padrão presumido, traduzir falsos cognatos automaticamente nem acrescentar exemplos que alterem o sentido explicado.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se explicar diferença de uso ou significado, mostre os exemplos fornecidos em painéis equivalentes e destaque o trecho referido. Não transforme uma comparação contextual em regra universal entre português e espanhol.

- Quando houver pronúncia, diálogo ou entonação, preserve o exemplo completo e seu contexto com a escrita correspondente. Identifique variedades regionais narradas; não uniformize sotaque nem adicione tradução ou representação fonética não fornecida.

Como a transcrição é PT-BR por padrão, valide espanhol, acentos, sinais de abertura e tempos contra áudio e material fornecido. Preserve formas regionais, erros intencionais e sons demonstrativos sem aplicar limpeza que modifique pronúncia. Se o PT-BR prejudicar os exemplos no outro idioma, adapte a cópia local da transcrição para um idioma suportado ou alinhe com o texto fornecido. Se não conseguir validar texto e tempos, sinalize o trecho e peça confirmação, sem aprovar uma legenda presumida.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 062 · Professor de física

**Área:** Educação

**Preset recomendado:** Grandezas em relação visível · AEIA-062

**Para que serve:** Acompanhar raciocínios de física com diagramas e relações temporais claras, distinguindo ilustração conceitual, demonstração real e simulação efetivamente calculada.

**Antes de gravar:** Forneça enunciado, símbolos e valores usados na explicação em material legível. Se demonstrar um experimento, grave o arranjo completo e mantenha instrumentos, escala e ação observável dentro do enquadramento.

**Ideia para testar:** Explique um diagrama preparado por você e forneça as convenções e equações que deseja mostrar.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Professor de física**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Grandezas em relação visível (AEIA-062)**

- Identidade: pessoa e interface + tipografia didática; base #233039, destaque #B9DCE6, texto #FFFFFF.
- Ênfases: par humanista-fino. Legenda: Editorial: blocos discretos integrados à composição. Blocos discretos ficam fora do diagrama e das equações; preservar grandezas, unidades e condições, com ênfase apenas na relação que o professor estiver estabelecendo.
- Ritmo: Introduzir elementos antes das relações e sustentar cada etapa do raciocínio; movimento ilustrativo não ganha velocidade ou trajetória física sem definição na explicação.
- Motivo visual: Diagrama com vetores nomeados e equação alinhada conecta representação, hipótese e relação narrada, distinguindo ilustração conceitual de simulação calculada.
- Recursos disponíveis para esta direção: vídeo em janela, com fundo coberto (recuo); checklist sincronizado aos itens narrados (listas).
- Cena temática (receita 2D a implementar): Quando o professor de física explicar uma relação entre grandezas ou um experimento, com sistema, condições e representação sustentados pela fala ou material fornecido no vídeo. Apresentar o sistema citado e acrescentar vetores, rótulos ou equações na ordem da explicação. Marcar animações conceituais como ilustrativas; dados e trajetórias calculadas só entram se fornecidos e conferidos, sem introduzir forças ou condições ausentes.
- Preserve no enquadramento: Preservar hipóteses, sentido dos vetores, notação, unidades e detalhes reais do experimento, sem legendas sobre o que está sendo observado.
- 3D: Experimento ou sistema 3D exige material fornecido e conferido para as condições narradas; sem ele, vistas 2D rotuladas sem fingir simulação física calculada.
- Cuidado específico: Não animar leis físicas por aparência, inventar forças, trocar unidades ou confundir um diagrama conceitual com resultado de experimento.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se a aula explicar forças ou trajetórias, construa o diagrama com os vetores narrados e mantenha convenções consistentes. Não invente magnitude ou direção para deixar a cena mais dinâmica.

- Quando desenvolver uma equação, revele cada passagem junto à justificativa oral, preservando hipóteses e unidades. Uma animação ilustrativa deve ser identificada e não aparentar reproduzir uma simulação física validada.

Confira sinais, unidades, referenciais e condições do modelo. Diferencie dado observado de exemplo calculado; gráficos ou movimentos criados precisam corresponder aos parâmetros fornecidos, sem fabricar evidência experimental. Conserve explicitamente as hipóteses do modelo.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 063 · Professor de química

**Área:** Educação

**Preset recomendado:** Símbolo e modelo químico · AEIA-063

**Para que serve:** Tornar explicações químicas legíveis entre símbolo e representação, preservando fórmulas, condições e distinção entre modelo ilustrativo e observação experimental registrada.

**Antes de gravar:** Forneça fórmulas, nomes e equações que aparecerão na aula em texto legível. Se mostrar materiais ou experimento autorizado, enquadre o arranjo completo e registre separadamente os detalhes mencionados.

**Ideia para testar:** Explique uma fórmula ou modelo molecular preparado, fornecendo a representação exata que deseja animar.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Professor de química**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Símbolo e modelo químico (AEIA-063)**

- Identidade: pessoa e interface + tipografia didática; base #293133, destaque #C4DDD2, texto #FFFFFF.
- Ênfases: par humanista-fino. Legenda: Editorial: blocos discretos integrados à composição. Legenda discreta separa narração de fórmula; preservar índices, cargas, condições e nomes completos, sem destacar partículas de modo que altere o significado da representação química.
- Ritmo: Apresentar símbolos e modelos na mesma etapa explicativa, mantendo a leitura antes da transformação; demonstrações reais preservam sequência sem efeitos que fabriquem observações.
- Motivo visual: Equação e representação identificada se correspondem por rótulos, diferenciando símbolo escrito, modelo molecular ilustrativo e observação experimental realmente registrada.
- Recursos disponíveis para esta direção: vídeo em janela, com fundo coberto (recuo); checklist sincronizado aos itens narrados (listas).
- Cena temática (receita 2D a implementar): Quando o professor de química relacionar uma fórmula a um modelo ou explicar uma transformação, com estruturas e condições claramente apresentadas na gravação ou material fornecido. Reproduzir os símbolos fornecidos com índices e cargas fiéis. Revelar a representação correspondente na hora da explicação, identificando o modelo como ilustrativo; qualquer experimento real permanece separado, sem inventar cor, gás, ligação ou etapa para completar a cena.
- Preserve no enquadramento: Preservar notação, condições, sequência e aspecto real do experimento, mantendo legendas fora das fórmulas e dos detalhes de observação.
- 3D: Modelo molecular 3D só com material fornecido e conferido para estrutura e geometria citadas; sem ele, representação 2D identificada sem ligações ou orientações inventadas.
- Cuidado específico: Não completar reações, alterar índices ou cargas nem representar uma mudança visual criada como observação de laboratório.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se explicar uma equação, revele reagentes, produtos e coeficientes conforme a narração, mantendo o conjunto visível na comparação. Não balanceie ou modifique automaticamente um exemplo usado pelo professor para discutir erros.

- Quando o tema exigir moléculas ou estrutura, use modelo bidimensional ou tridimensional conferido com legenda de suas convenções. Movimentos ilustrativos não devem fingir simular dinâmica molecular nem inventar mecanismos de reação.

Confira índices, cargas, ligações e coeficientes com o material fornecido. Diferencie modelo e experimento; não acrescente substâncias, quantidades, etapas ou recomendações práticas para preencher lacunas de gravação. Identifique convenções das cores moleculares.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 064 · Professor de biologia

**Área:** Educação

**Preset recomendado:** Escalas biológicas conectadas · AEIA-064

**Para que serve:** Guiar explicações biológicas entre escalas e etapas com modelos identificados, evitando que recursos gráficos acrescentem funções, processos ou evidências não apresentados.

**Antes de gravar:** Nomeie claramente as estruturas e as mudanças de escala que usará na explicação. Forneça desenhos ou imagens de referência com origem identificada e capture os materiais em posição estável e legível.

**Ideia para testar:** Apresente uma estrutura em duas escalas usando referências fornecidas e explique como elas se relacionam.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Professor de biologia**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Escalas biológicas conectadas (AEIA-064)**

- Identidade: pessoa e interface + tipografia didática; base #26332B, destaque #C7DEA9, texto #FFFFFF.
- Ênfases: par editorial-leve. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Frases estáveis mantêm nomes de estruturas e relações; distinguir a legenda da narração dos rótulos de escala, preservando condições sem transformar funções em palavras isoladas.
- Ritmo: Ancorar cada aproximação na vista anterior e revelar processos somente na ordem narrada; a mudança de escala precisa orientar a compreensão, sem viagem microscópica decorativa.
- Motivo visual: Janelas de escala conectadas e etapas rotuladas separam organismo, estrutura e processo, mantendo uma referência identificável entre níveis explicados.
- Recursos disponíveis para esta direção: vídeo em janela, com fundo coberto (recuo); checklist sincronizado aos itens narrados (listas).
- Cena temática (receita 2D a implementar): Quando o professor de biologia passar entre escalas ou explicar etapas de um processo, com estruturas, relações e sequência efetivamente nomeadas no conteúdo fornecido pelo autor. Mostrar a referência inicial e abrir a escala citada em uma janela identificada. Revelar estruturas e etapas junto à fala, preservando a correspondência; materiais reais mantêm identificação própria e o esquema não acrescenta organelas, funções ou eventos presumidos.
- Preserve no enquadramento: Preservar nomes, correspondência entre escalas e identificação de imagens reais, sem atribuir ao desenho a aparência de observação microscópica.
- 3D: Estrutura biológica 3D exige material fornecido e conferido para o nível e processo citados; sem ele, esquema 2D ilustrativo com escalas claramente identificadas.
- Cuidado específico: Não fabricar microscopia, inventar funções ou acelerar processos como se fossem observação real sem identificar a ilustração.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se a aula passar de organismo para órgão, tecido ou célula, desenhe a transição em painéis 2D rotulados com referência de escala. Um tamanho ampliado para leitura não deve sugerir proporção real.

- Quando explicar ciclo ou processo, escreva cenas esquemáticas que evoluam com a narração e identifique a estrutura relevante. Modelos 3D dependem de material compatível disponível; sem ele, use diagramas fiéis e diferencie ilustração de observação.

Confira nomenclatura, sequência, escala e convenções visuais com as referências fornecidas. Não invente propriedades ou relações evolutivas e não transforme semelhança gráfica em evidência de função ou parentesco.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 065 · Professor de história

**Área:** Educação

**Preset recomendado:** Cronologia com fonte à vista · AEIA-065

**Para que serve:** Organizar narrativas históricas com cronologia e fontes identificáveis, preservando distinções entre acontecimento, interpretação e reconstrução ilustrativa apresentada na aula.

**Antes de gravar:** Forneça nomes, datas e fontes que deseja exibir, com imagens autorizadas quando houver. Sinalize na fala mudanças de período e indique quando apresentar uma interpretação, hipótese ou citação de documento.

**Ideia para testar:** Explique uma pequena sequência de eventos usando datas e referências previamente escolhidas por você.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Professor de história**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Cronologia com fonte à vista (AEIA-065)**

- Identidade: pessoa e interface + editorial; base #322D26, destaque #DEC9A2, texto #FFFFFF.
- Ênfases: par geometrica-serifa. Legenda: Editorial: blocos discretos integrados à composição. Blocos editoriais preservam datas, atribuições e distinções de interpretação; a ênfase organiza um marco narrado, sem cobrir trechos de documento ou transformar hipótese em afirmação.
- Ritmo: Acompanhar o encadeamento histórico explicado, preservando o tempo de leitura da fonte; transições marcam mudança de período ou perspectiva, sem misturar eventos simultâneos e sucessivos.
- Motivo visual: Marcos cronológicos e molduras de documento distinguem acontecimento narrado, fonte apresentada e interpretação do professor, sem produzir arquivos de época falsos.
- Recursos disponíveis para esta direção: vídeo em janela, com fundo coberto (recuo); checklist sincronizado aos itens narrados (listas).
- Cena temática (composição sobre material fornecido): Quando o professor de história relacionar acontecimentos ou comentar uma fonte fornecida, com períodos, atribuições e interpretação sustentados pela gravação ou pelos materiais disponíveis do autor. Construir a linha temporal apenas com os marcos citados e mostrar o documento original em janela própria. Destacar o trecho comentado mantendo identificação disponível; reconstruções fornecidas são rotuladas como ilustração, sem aparência de arquivo histórico autêntico.
- Preserve no enquadramento: Preservar datas, atribuições, contexto de citação e identificação das fontes, mantendo o trecho documental legível fora da legenda da narração.
- 3D: Reconstrução histórica 3D somente se fornecida, conferida e identificada como ilustrativa para a relação espacial narrada; sem ela, mapa ou esquema 2D contextualizado.
- Cuidado específico: Não inventar fotografias de época, manuscritos, datas ou frases; evitar que uma transição transforme interpretação em evidência documental.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se houver sequência temporal, construa uma linha do tempo com os marcos citados e mantenha o período atual destacado. Não acrescente datas ou relações de causa para tornar a narrativa mais linear.

- Quando apresentar documento, imagem ou citação, mostre o trecho fornecido com origem disponível e destaque apenas a passagem comentada. Uma ilustração gerada precisa ser identificada como reconstrução, sem aparentar registro de época.

Confira datas, nomes, citações e autoria contra o roteiro fornecido. Não invente falas, imagens de arquivo ou causalidades; distinções entre fonte, interpretação e reconstrução devem permanecer visíveis na montagem.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 066 · Professor de geografia

**Área:** Educação

**Preset recomendado:** Mapa, escala e contexto · AEIA-066

**Para que serve:** Apresentar relações espaciais e dados geográficos com mapas legíveis e escalas claras, preservando origem, período e limites das informações utilizadas.

**Antes de gravar:** Forneça o mapa ou os dados que deseja explicar com sua origem e período. Indique verbalmente a região, a escala e as mudanças de enquadramento, evitando apontar áreas fora da câmera.

**Ideia para testar:** Explique uma mudança de escala usando um mapa fornecido e identifique a região em cada vista.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Professor de geografia**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Mapa, escala e contexto (AEIA-066)**

- Identidade: pessoa e interface + tipografia didática; base #25312E, destaque #C7DBC5, texto #FFFFFF.
- Ênfases: par humanista-fino. Legenda: Editorial: blocos discretos integrados à composição. Blocos discretos preservam nomes, períodos e unidades; manter a legenda da fala separada da legenda cartográfica, sem cobrir escala, fonte ou região destacada no mapa.
- Ritmo: Orientar a vista geral antes de aproximar a região citada; fluxos e comparações aparecem na ordem explicada, sem saltos que confundam escala ou localização.
- Motivo visual: Mapa com janela de localização, legenda própria e fluxos nomeados organiza relações espaciais, mantendo origem, período e limites dos dados fornecidos.
- Recursos disponíveis para esta direção: vídeo em janela, com fundo coberto (recuo); reenquadramentos pontuais (planos).
- Cena temática (composição sobre material fornecido): Quando o professor de geografia explicar uma região, fluxo ou indicador em mapa fornecido, com escala e contexto suficientes para a comparação apresentada no vídeo original. Exibir o mapa original com sua referência e destacar a região mencionada. Aproximar sem perder a localização geral; revelar fluxos ou indicadores somente com informação fornecida, mantendo legenda e período e sem gerar limites geográficos ou valores novos.
- Preserve no enquadramento: Preservar orientação, limites, escala, fonte e período do mapa, com legenda cartográfica e unidades legíveis durante a explicação.
- 3D: Relevo ou globo 3D só com material fornecido e conferido para a relação espacial explicada; sem ele, mapa 2D rotulado sem altitudes ou limites inventados.
- Cuidado específico: Não deformar regiões, criar fronteiras, variar escalas silenciosamente ou desenhar fluxos que pareçam dados quando são apenas ilustração.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se a explicação mudar de escala, localize primeiro a região e depois aproxime o detalhe mantendo uma referência espacial. Use limites e nomes de uma fonte fornecida ou verificável, sem gerar geografia por aparência.

- Quando representar fluxos ou rotas, anime somente trajetos sustentados pelos dados e diferencie sentido de movimento de intensidade. A largura e a velocidade das linhas não podem insinuar valores que não foram informados.

Confira localização, orientação, legenda e correspondência entre mapa e dados. Não invente fronteiras, estatísticas ou trajetos; as cenas personalizadas exigem uma base geográfica fornecida ou verificada, sem deduzir esses dados pela animação.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 067 · Pedagogo alfabetizador

**Área:** Educação

**Preset recomendado:** Som, traço e unidade escrita · AEIA-067

**Para que serve:** Organizar conteúdos de alfabetização com exemplos visuais e sonoros coerentes, respeitando o percurso didático apresentado sem criar associações ou desempenhos inexistentes.

**Antes de gravar:** Forneça as palavras, letras ou materiais que usará e grave cada exemplo sonoro com clareza. Posicione a câmera para mostrar o gesto completo de escrita ou manipulação, sem expor dados de crianças.

**Ideia para testar:** Demonstre uma atividade autoral curta e forneça as palavras e os materiais que devem aparecer.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Pedagogo alfabetizador**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Som, traço e unidade escrita (AEIA-067)**

- Identidade: pessoa e interface + tipografia didática; base #303329, destaque #E0DDA5, texto #FFFFFF.
- Ênfases: par editorial-leve. Legenda: Convencional: blocos estáveis de frase, entrada suave, sem karaokê. Blocos claros separam a orientação do exemplo escrito; preservar a unidade ensinada e o som real, sem animações que dividam palavras em segmentos diferentes dos explicados.
- Ritmo: Respeitar o tempo de observar, ouvir e acompanhar o traçado; repetir apenas o que o professor demonstrar, sem antecipar resposta ou simular progresso do aluno.
- Motivo visual: Unidade escrita estável, traçado progressivo fiel e imagem de apoio citada relacionam som e grafia sem estímulos visuais concorrentes durante a demonstração.
- Recursos disponíveis para esta direção: vídeo em janela, com fundo coberto (recuo); checklist sincronizado aos itens narrados (listas).
- Cena temática (receita 2D a implementar): Quando o pedagogo alfabetizador relacionar uma unidade escrita a um som ou demonstrar seu traçado, com sequência e exemplo explicitamente apresentados no vídeo ou material do autor. Apresentar a unidade exatamente como fornecida e realçar o segmento na fala correspondente. Se houver traçado, seguir a demonstração registrada; imagens de apoio só entram quando relacionadas pelo professor, sem acrescentar associações ou fingir resposta de uma criança.
- Preserve no enquadramento: Preservar grafia, ordem do traçado, exemplo sonoro e legibilidade da unidade, além da privacidade de crianças eventualmente presentes.
- 3D: Evitar letras 3D que alterem o reconhecimento; objeto fornecido e conferido pode apoiar exemplo espacial narrado, com imagem 2D simples e identificada quando faltar material.
- Cuidado específico: Não inventar associação entre letra e som, mudar o traçado ou transformar a edição em prova de aprendizagem de uma criança.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se a atividade relacionar som e escrita, destaque somente a unidade que o pedagogo nomear, acompanhando o exemplo real. Não fragmente automaticamente palavras em letras ou sílabas se essa não for a abordagem apresentada.

- Quando demonstrar traçado ou manipulação de material, preserve a ordem e a direção do gesto com detalhe suficiente. Uma animação de escrita deve corresponder ao modelo fornecido, sem inventar um caminho ideal.

Confira unidade sonora, grafia, imagem e gesto contra o material. Preserve fonemas e exemplos originais, suspendendo cortes ou limpeza que os alterem; não fabrique acertos, evolução ou participação infantil nem corrija exemplos intencionais.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 068 · Professor preparatório para concursos e vestibulares

**Área:** Educação

**Preset recomendado:** Questão revelada pelo raciocínio · AEIA-068

**Para que serve:** Tornar resolução e estratégia de provas compreensíveis, mantendo enunciado, alternativas e justificativas alinhados sem revelar respostas ou criar regras antes da explicação.

**Antes de gravar:** Forneça a questão com fonte, ano e gabarito que deseja usar, respeitando o acesso ao material. Grave a leitura das partes relevantes e marque verbalmente as etapas de análise e conclusão.

**Ideia para testar:** Resolva uma questão autoral curta com alternativas e forneça o gabarito e a justificativa.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Professor preparatório para concursos e vestibulares**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Questão revelada pelo raciocínio (AEIA-068)**

- Identidade: pessoa e interface + tipografia didática; base #293039, destaque #DED7AA, texto #FFFFFF.
- Ênfases: par condensada. Legenda: Editorial: blocos discretos integrados à composição. Blocos discretos narram a estratégia fora do enunciado; a ênfase condensada nomeia a etapa, mantendo qualificadores e sem revelar alternativa correta antes da justificativa.
- Ritmo: Dar tempo para ler o enunciado e acompanhar a análise de cada alternativa; marcações surgem com a justificativa, sem antecipar a conclusão do professor.
- Motivo visual: Enunciado estável, marcações progressivas e alternativas preservadas orientam a resolução, distinguindo leitura, critério explicado e conclusão efetivamente apresentada pelo professor.
- Recursos disponíveis para esta direção: vídeo em janela, com fundo coberto (recuo); checklist sincronizado aos itens narrados (listas).
- Cena temática (composição sobre material fornecido): Quando o professor preparatório resolver uma questão ou explicar estratégia em material fornecido, com enunciado, alternativas e justificativas identificáveis na gravação e suficientes para a montagem. Exibir a questão fielmente e destacar apenas o trecho comentado. Marcar alternativas quando a explicação sustentar a ação, mantendo as demais disponíveis para comparação; a resposta e eventuais cálculos aparecem somente na etapa em que forem apresentados pelo professor.
- Preserve no enquadramento: Preservar enunciado, alternativas, qualificadores e notação, com origem da questão quando fornecida e sem legenda sobre o trecho analisado.
- 3D: Usar geometria 3D somente se fornecida e conferida para uma questão espacial; sem ela, vistas 2D rotuladas sem inventar medidas ou relações ausentes do enunciado.
- Cuidado específico: Não dar spoiler da resposta, apagar alternativa antes da justificativa ou criar regras de prova e macetes que o professor não ensinou.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se resolver uma questão, mantenha enunciado e alternativas legíveis enquanto destaca o trecho comentado. Só revele eliminações e resposta no ponto definido pela explicação, sem antecipação provocada pelo desenho da tela.

- Quando apresentar uma estratégia, organize as etapas efetivamente narradas com exemplos fornecidos, distinguindo método de estudo de regra do exame. Não acrescente atalhos, estatísticas de incidência ou promessas de aprovação.

Confira prova, ano, enunciado, alternativas e gabarito com a fonte fornecida. Não atualize normas, edital ou resposta por suposição; divergências devem ser indicadas sem uma correção inventada pela edição.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```


---

# 069 · Professor de programação

**Área:** Educação

**Preset recomendado:** Código, execução e estado · AEIA-069

**Para que serve:** Editar aulas de programação conectando código, execução e explicação, com trechos legíveis e estados verificáveis sem fabricar funcionamento ou ocultar etapas essenciais.

**Antes de gravar:** Grave a tela com fonte legível e forneça os arquivos usados na aula sem chaves ou dados privados. Informe linguagem e ambiente relevantes e sinalize quando alternar entre código, execução e diagrama.

**Ideia para testar:** Explique um pequeno programa autoral e forneça código, entrada e saída esperada para conferência.

**Uso:** copie o bloco completo e informe o caminho do vídeo. As preferências podem ser preenchidas ou deixadas para o Claude decidir.

## Prompt para copiar

```text
Use a skill **do-bruto-ao-pronto** instalada no Claude Code para editar este vídeo de **Professor de programação**, com Remotion. Entregue uma edição clara, profissional e fiel à fala, usando o preset abaixo como direção adaptável ao vídeo.

CONFIGURAÇÃO
- Vídeo: [CAMINHO COMPLETO DO VÍDEO]
- Pasta de saída: [AUTOMÁTICA OU CAMINHO]
- Formato: [AUTOMÁTICO / REELS 9:16 / YOUTUBE 16:9]
- Qualidade: [1080p30 / 1080p60 / 4K]
- Duração: [CONTEÚDO COMPLETO OU LIMITE DESEJADO]
- Preset: [RECOMENDADO DESTA PROFISSÃO / AUTOMÁTICO LIVRE / DESCREVER]
- Estilo visual: [AUTOMÁTICO OU PREFERÊNCIA]
- Legenda: [AUTOMÁTICA OU PREFERÊNCIA]
- Complementos: [AUTOMÁTICOS / NENHUM / DESCREVER]
- Materiais de apoio, logo e referências: [NENHUM OU CAMINHOS]

**1. Preparação e cortes**

Leia o SKILL.md e os catálogos de estilos, legendas e efeitos. Confirme acesso ao vídeo e às dependências. Crie um projeto exclusivo, preservando o original e a skill instalada; personalize apenas a cópia do projeto. Em saída automática, use uma subpasta de videos-prontos com profissão e data/hora.

Confira a taxa real de quadros e se a fonte é CFR ou VFR. Em FPS fracionário ou variável, não aplique cortes por quadros usando FPS arredondado: prepare uma cópia de trabalho CFR com imagem e áudio sincronizados, refaça os dados a partir dela e confira a correspondência com a origem. Não altere o original. Se não conseguir validar essa preparação, informe o bloqueio antes de cortar.

Sem preenchimento, mantenha orientação gravada, 1080p30 e conteúdo completo. Use o preset recomendado como ponto de partida, ajustando-o ao cenário, à fala e aos materiais. Minhas preferências e referências têm prioridade; AUTOMÁTICO LIVRE permite outra direção. NENHUM em complementos mantém cortes, enquadramento e legendas, sem apoios extras. Se a duração pedida eliminar informação essencial, apresente o conflito.

Identifique explicação, demonstração, apresentação ou relato. Remova erros, bastidores, tomadas descartadas, repetições acidentais e pausas excessivas; atenue respiros incômodos preservando palavras completas, negações, ressalvas e pausas intencionais. Preserve o tempo de observar gestos e processos. Em performance, mantenha a limpeza de fala fora da execução original; preserve notas, fraseado, respirações expressivas e canais. Se a cadeia de voz alterar a performance, ajuste a cópia do projeto antes de processá-la ou informe o bloqueio.

**2. Preset recomendado — Código, execução e estado (AEIA-069)**

- Identidade: pessoa e interface + tipografia didática; base #202D32, destaque #B9DFCE, texto #FFFFFF.
- Ênfases: par humanista-fino. Legenda: Editorial: blocos discretos integrados à composição. Blocos discretos preservam identificadores e contexto da explicação; deixar código e saída livres, sem transcrever símbolos de forma ambígua ou competir com a linha ativa.
- Ritmo: Conectar a linha explicada à execução correspondente e sustentar o estado resultante; cortes podem retirar espera, mantendo identificada a continuidade e sem fingir execução imediata.
- Motivo visual: Linha ativa, fluxo de execução e janela de saída relacionam código real e estado observado, distinguindo explicação conceitual de demonstração efetivamente executada.
- Recursos disponíveis para esta direção: vídeo em janela, com fundo coberto (recuo); checklist sincronizado aos itens narrados (listas).
- Cena temática (composição sobre material fornecido): Quando o professor de programação relacionar uma linha de código à execução ou à interface, usando gravação e arquivos que permitam identificar o comportamento realmente demonstrado. Mostrar o código fornecido em tamanho legível e marcar a linha durante sua explicação. Exibir a execução correspondente sem inventar saída; se uma espera for abreviada, manter sua identificação e não esconder erros que integrem o raciocínio ensinado.
- Preserve no enquadramento: Preservar indentação, identificadores, sinais, mensagens e estado real da execução, sem expor credenciais, dados pessoais ou arquivos fora do exemplo.
- 3D: Usar objeto 3D fornecido e conferido apenas se o código ensinado tratar dessa cena; sem ele, diagrama 2D ilustrativo de fluxo, sem execução inventada.
- Cuidado específico: Não completar código, fabricar saída funcionando ou ocultar um erro que muda o comportamento explicado pelo professor na demonstração.

Este nome identifica a direção deste prompt; não é comando nativo. Selecione só os recursos que ajudem neste vídeo, sem obrigação de usar todos. Ajuste cores para contraste, legibilidade e identidade fornecida. Mantenha uma cor de destaque e poucas ênfases; clareza tem prioridade sobre efeitos.

**3. Aplicação à profissão**

- Se explicar código, destaque o trecho mencionado e mantenha contexto suficiente para entender variáveis, chamadas e dependências. Não transforme cada palavra falada em texto de código nem reescreva exemplos sem verificar a execução.

- Quando demonstrar interação ou saída, preserve a sequência real entre entrada, ação e resultado. Uma interface animada ilustrativa deve estar identificada e não substituir uma execução que o vídeo pretende comprovar.

Confira sintaxe, nomes, saídas e versão declarada contra os arquivos. Não invente resultados, benchmarks ou comandos; remova segredos visíveis sem apagar informações necessárias para compreender o comportamento demonstrado.

Priorize materiais fornecidos e a demonstração real. Identifique esquemas conceituais como ilustrativos. Não acrescente fatos, medidas, resultados ou etapas ausentes da fala e das referências. O perfil de 3D acima é condicional: informe a limitação se faltar material adequado e use a alternativa indicada.

**4. Sincronização e execução visual**

Transcreva a fala e confira termos técnicos e números; execução instrumental não vira texto. Após fechar os cortes, registre em ROTEIRO.md as ideias relevantes, seus tempos na versão editada e o apoio escolhido, incluindo a abertura. O elemento deve estar reconhecível quando for mencionado; a entrada animada não pode atrasar a explicação. Faça a cena evoluir com cada etapa narrada. Se a gravação já demonstrar a ideia, mantenha esse trecho visível.

Converta o preset em configurações realmente consumidas pelo motor e em cenas da cópia do projeto. Implemente receitas em src/cenas/Cenas.tsx com os recursos existentes e animação por tempo/quadro. Os pares de fonte configuram as ênfases; uma legenda-base diferente exige implementação no componente da cópia, preservando tempos e texto. A cor de texto indicada precisa ser aplicada e conferida em cada componente; campos globais podem não alterá-lo. Apenas registrar o nome ou adicionar campos ao JSON não basta. Sem recorte válido, substitua efeitos atrás da pessoa por cartões ou tela ilustrativa sem cobrir a ação.

Se mudar os cortes, atualize tempos, legendas, sons e recortes afetados. Confira FPS e sincronismo antes de reaproveitar dados intermediários. Só reutilize transcrições e máscaras quando corresponderem à fonte, ao áudio, aos cortes e aos parâmetros atuais; invalide o cache incompatível e gere novamente o necessário.

**5. Legendas, enquadramento e som**

Adapte a legenda ao preset e à densidade da explicação, respeitando minha preferência. Preserve pontuação, contexto e início/fim das palavras; use quebras naturais, contraste e leitura confortável. Evite dois textos grandes simultâneos. Confira rosto e as regiões protegidas pelo perfil tanto no vertical quanto no horizontal; adapte a composição quando necessário.

Em vídeos falados, priorize a voz. Use somente sons disponíveis e licenciados, discretos e medidos abaixo da fala; preserve sons originais relevantes. Em comparações sonoras, mantenha os ganhos relativos, sem normalizar versões isoladamente e apagar a diferença demonstrada. Sem música adicionada por padrão. Não imponha transições, zooms ou mudanças por uma frequência fixa.

**6. Revisão e entrega**

Respeite as aprovações da fala limpa e do vídeo de revisão previstas na skill. Nas decisões estéticas automáticas, decida por mim. Confira quadros de prova da abertura, das cenas e da legenda antes do render completo. Execute as verificações pertinentes e corrija erros de código, arquivos ausentes e falhas visuais encontradas.

Confira o MP4 exportado inteiro: cortes, voz/imagem, entrada dos apoios, legibilidade, enquadramento, áudio e final completo. Decodifique o arquivo completo e confira se contém quadros, faixas esperadas e duração coerente; uma leitura que falhou ou não produziu dados não conta como aprovação. Leia os resultados das verificações, mesmo que o processo termine com sucesso. Use medidas e retranscrição dos trechos verbais para checagem automática do áudio, sem alegar escuta. Apresente a revisão e pendências concretas; solicite minha escuta. Após aprovação, entregue MP4 final, SRT dos trechos verbais quando existirem, projeto editável e relatório conforme a skill. Se houver bloqueio, identifique a causa sem declarar a edição concluída.

**7. Qualidade, economia e continuidade**

Economize tokens com respostas objetivas, logs resumidos e prévias leves. Reaproveite etapas válidas; preserve verificações essenciais. Mantenha CONTINUAR.md com caminhos, preset aplicado, ajustes, etapas concluídas, pendências, aprovações e próximo passo. Antes de compactar ou trocar de sessão, atualize o registro. Inicie outra sessão somente se o ambiente permitir; caso contrário, entregue uma instrução curta para retomada pelo registro, sem reiniciar o que já foi validado.
```
