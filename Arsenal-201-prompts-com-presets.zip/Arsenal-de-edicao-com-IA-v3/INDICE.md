# Escolha sua profissão

201 prompts completos · 18 grupos · versão 3.0.1.

[Como usar](COMECE-AQUI.md) · [Visão dos 201 presets](MAPA-DE-PRESETS.md) · [Plano de testes](PLANO-DE-TESTES.md)

## 01 · Medicina — 22

[Abrir grupo completo](grupos/01-medicina.md)

- [001 · Médico clínico geral](prompts/01-medicina/001-medico-clinico-geral.md) — Consulta em contexto
- [002 · Médico dermatologista](prompts/01-medicina/002-medico-dermatologista.md) — Pele em camadas
- [003 · Médico pediatra](prompts/01-medicina/003-medico-pediatra.md) — Cuidado que acompanha
- [004 · Médico cardiologista](prompts/01-medicina/004-medico-cardiologista.md) — Percurso do coração
- [005 · Médico endocrinologista](prompts/01-medicina/005-medico-endocrinologista.md) — Sinais e relações hormonais
- [006 · Médico ginecologista](prompts/01-medicina/006-medico-ginecologista.md) — Anatomia com acolhimento
- [007 · Médico obstetra](prompts/01-medicina/007-medico-obstetra.md) — Gestação em marcos narrados
- [008 · Médico psiquiatra](prompts/01-medicina/008-medico-psiquiatra.md) — Nuances em primeiro plano
- [009 · Médico neurologista](prompts/01-medicina/009-medico-neurologista.md) — Mapa neural orientado
- [010 · Médico ortopedista](prompts/01-medicina/010-medico-ortopedista.md) — Articulação em movimento
- [011 · Médico oftalmologista](prompts/01-medicina/011-medico-oftalmologista.md) — Visão em foco explicado
- [012 · Médico otorrinolaringologista](prompts/01-medicina/012-medico-otorrinolaringologista.md) — Canais e conexões
- [013 · Médico urologista](prompts/01-medicina/013-medico-urologista.md) — Percurso urológico claro
- [014 · Médico gastroenterologista](prompts/01-medicina/014-medico-gastroenterologista.md) — Trajeto digestivo guiado
- [015 · Médico pneumologista](prompts/01-medicina/015-medico-pneumologista.md) — Respiração em percurso
- [016 · Médico nutrólogo](prompts/01-medicina/016-medico-nutrologo.md) — Metabolismo em contexto
- [017 · Médico do esporte](prompts/01-medicina/017-medico-do-esporte.md) — Movimento com contexto clínico
- [018 · Médico geriatra](prompts/01-medicina/018-medico-geriatra.md) — Rotina com autonomia
- [019 · Médico oncologista](prompts/01-medicina/019-medico-oncologista.md) — Cuidado em etapas condicionais
- [020 · Médico cirurgião plástico](prompts/01-medicina/020-medico-cirurgiao-plastico.md) — Planos anatômicos transparentes
- [021 · Médico infectologista](prompts/01-medicina/021-medico-infectologista.md) — Relações de transmissão narradas
- [022 · Médico reumatologista](prompts/01-medicina/022-medico-reumatologista.md) — Articulação e experiência

## 02 · Outras profissões da saúde — 14

[Abrir grupo completo](grupos/02-outras-profissoes-da-saude.md)

- [023 · Dentista clínico geral](prompts/02-outras-profissoes-da-saude/023-dentista-clinico-geral.md) — Dente e processo sincronizados
- [024 · Dentista ortodontista](prompts/02-outras-profissoes-da-saude/024-dentista-ortodontista.md) — Arcadas em relação
- [025 · Dentista implantodontista](prompts/02-outras-profissoes-da-saude/025-dentista-implantodontista.md) — Componentes do implante
- [026 · Dentista odontopediatra](prompts/02-outras-profissoes-da-saude/026-dentista-odontopediatra.md) — Sorriso explicado com cuidado
- [027 · Dentista endodontista](prompts/02-outras-profissoes-da-saude/027-dentista-endodontista.md) — Interior dental revelado
- [028 · Nutricionista](prompts/02-outras-profissoes-da-saude/028-nutricionista.md) — Alimento em contexto real
- [029 · Psicólogo](prompts/02-outras-profissoes-da-saude/029-psicologo.md) — Relações sem rótulos
- [030 · Neuropsicólogo](prompts/02-outras-profissoes-da-saude/030-neuropsicologo.md) — Funções em tarefa contextual
- [031 · Fisioterapeuta](prompts/02-outras-profissoes-da-saude/031-fisioterapeuta.md) — Gesto terapêutico legível
- [032 · Fonoaudiólogo](prompts/02-outras-profissoes-da-saude/032-fonoaudiologo.md) — Voz e articulação preservadas
- [033 · Enfermeiro](prompts/02-outras-profissoes-da-saude/033-enfermeiro.md) — Etapas observáveis do cuidado
- [034 · Farmacêutico](prompts/02-outras-profissoes-da-saude/034-farmaceutico.md) — Informação de embalagem em foco
- [035 · Biomédico](prompts/02-outras-profissoes-da-saude/035-biomedico.md) — Amostra ao processo narrado
- [036 · Terapeuta ocupacional](prompts/02-outras-profissoes-da-saude/036-terapeuta-ocupacional.md) — Atividade e adaptação visíveis

## 03 · Beleza e estética — 12

[Abrir grupo completo](grupos/03-beleza-e-estetica.md)

- [037 · Cabeleireiro](prompts/03-beleza-e-estetica/037-cabeleireiro.md) — Mechas, direção e acabamento
- [038 · Barbeiro](prompts/03-beleza-e-estetica/038-barbeiro.md) — Degradê em faixas claras
- [039 · Maquiador](prompts/03-beleza-e-estetica/039-maquiador.md) — Mapa de aplicação fiel
- [040 · Manicure / nail designer](prompts/03-beleza-e-estetica/040-manicure-nail-designer.md) — Formato e superfície em macro
- [041 · Designer de sobrancelhas](prompts/03-beleza-e-estetica/041-designer-de-sobrancelhas.md) — Marcações com referência real
- [042 · Lash designer](prompts/03-beleza-e-estetica/042-lash-designer.md) — Mapa de cílios em detalhe
- [043 · Esteticista](prompts/03-beleza-e-estetica/043-esteticista.md) — Procedimento com contexto visível
- [044 · Micropigmentador](prompts/03-beleza-e-estetica/044-micropigmentador.md) — Desenho, aplicação e registro
- [045 · Trancista](prompts/03-beleza-e-estetica/045-trancista.md) — Divisões e entrelaços legíveis
- [046 · Tatuador](prompts/03-beleza-e-estetica/046-tatuador.md) — Traço autoral e pele real
- [047 · Podólogo](prompts/03-beleza-e-estetica/047-podologo.md) — Região e instrumento sob cuidado
- [048 · Massoterapeuta](prompts/03-beleza-e-estetica/048-massoterapeuta.md) — Direção e continuidade do toque

## 04 · Fitness e esportes — 9

[Abrir grupo completo](grupos/04-fitness-e-esportes.md)

- [049 · Personal trainer](prompts/04-fitness-e-esportes/049-personal-trainer.md) — Repetição completa e clara
- [050 · Instrutor de Pilates](prompts/04-fitness-e-esportes/050-instrutor-de-pilates.md) — Apoios e fases do Pilates
- [051 · Professor de yoga](prompts/04-fitness-e-esportes/051-professor-de-yoga.md) — Prática em continuidade serena
- [052 · Treinador de corrida](prompts/04-fitness-e-esportes/052-treinador-de-corrida.md) — Passada e contexto visíveis
- [053 · Professor de dança](prompts/04-fitness-e-esportes/053-professor-de-danca.md) — Passos no tempo da dança
- [054 · Treinador de CrossFit](prompts/04-fitness-e-esportes/054-treinador-de-crossfit.md) — Blocos e transições do treino
- [055 · Professor de artes marciais](prompts/04-fitness-e-esportes/055-professor-de-artes-marciais.md) — Trajetória e distância claras
- [056 · Professor de natação](prompts/04-fitness-e-esportes/056-professor-de-natacao.md) — Ciclo aquático orientado
- [057 · Treinador de futebol](prompts/04-fitness-e-esportes/057-treinador-de-futebol.md) — Campo tático em sequência

## 05 · Educação — 12

[Abrir grupo completo](grupos/05-educacao.md)

- [058 · Professor de português](prompts/05-educacao/058-professor-de-portugues.md) — Frase em transformação comentada
- [059 · Professor de matemática](prompts/05-educacao/059-professor-de-matematica.md) — Raciocínio em linhas preservadas
- [060 · Professor de inglês](prompts/05-educacao/060-professor-de-ingles.md) — Inglês escrito e ouvido
- [061 · Professor de espanhol](prompts/05-educacao/061-professor-de-espanhol.md) — Espanhol em contraste contextual
- [062 · Professor de física](prompts/05-educacao/062-professor-de-fisica.md) — Grandezas em relação visível
- [063 · Professor de química](prompts/05-educacao/063-professor-de-quimica.md) — Símbolo e modelo químico
- [064 · Professor de biologia](prompts/05-educacao/064-professor-de-biologia.md) — Escalas biológicas conectadas
- [065 · Professor de história](prompts/05-educacao/065-professor-de-historia.md) — Cronologia com fonte à vista
- [066 · Professor de geografia](prompts/05-educacao/066-professor-de-geografia.md) — Mapa, escala e contexto
- [067 · Pedagogo alfabetizador](prompts/05-educacao/067-pedagogo-alfabetizador.md) — Som, traço e unidade escrita
- [068 · Professor preparatório para concursos e vestibulares](prompts/05-educacao/068-professor-preparatorio-para-concursos-e-vestibulares.md) — Questão revelada pelo raciocínio
- [069 · Professor de programação](prompts/05-educacao/069-professor-de-programacao.md) — Código, execução e estado

## 06 · Direito — 11

[Abrir grupo completo](grupos/06-direito.md)

- [070 · Advogado trabalhista](prompts/06-direito/070-advogado-trabalhista.md) — Fatos e documentos em sequência
- [071 · Advogado previdenciário](prompts/06-direito/071-advogado-previdenciario.md) — Histórico e critérios contextualizados
- [072 · Advogado de família](prompts/06-direito/072-advogado-de-familia.md) — Relações familiares com contexto
- [073 · Advogado criminalista](prompts/06-direito/073-advogado-criminalista.md) — Etapas e atribuições sem julgamento
- [074 · Advogado consumerista](prompts/06-direito/074-advogado-consumerista.md) — Jornada de consumo documentada
- [075 · Advogado empresarial](prompts/06-direito/075-advogado-empresarial.md) — Vínculos empresariais legíveis
- [076 · Advogado tributarista](prompts/06-direito/076-advogado-tributarista.md) — Premissas e cenários tributários
- [077 · Advogado imobiliário](prompts/06-direito/077-advogado-imobiliario.md) — Imóvel e percurso documental
- [078 · Advogado de direito digital](prompts/06-direito/078-advogado-de-direito-digital.md) — Dados, interface e responsabilidade
- [079 · Advogado bancário](prompts/06-direito/079-advogado-bancario.md) — Cláusula e base de comparação
- [080 · Advogado de direito médico](prompts/06-direito/080-advogado-de-direito-medico.md) — Papéis e registros do cuidado

## 07 · Finanças e contabilidade — 8

[Abrir grupo completo](grupos/07-financas-e-contabilidade.md)

- [081 · Contador](prompts/07-financas-e-contabilidade/081-contador.md) — Documento que vira lançamento
- [082 · Consultor financeiro](prompts/07-financas-e-contabilidade/082-consultor-financeiro.md) — Orçamento em caminhos claros
- [083 · Planejador financeiro](prompts/07-financas-e-contabilidade/083-planejador-financeiro.md) — Horizonte de metas por etapas
- [084 · Assessor de investimentos](prompts/07-financas-e-contabilidade/084-assessor-de-investimentos.md) — Produto com condições à vista
- [085 · Analista de investimentos](prompts/07-financas-e-contabilidade/085-analista-de-investimentos.md) — Evidência, premissa e leitura
- [086 · Economista](prompts/07-financas-e-contabilidade/086-economista.md) — Relações econômicas em contexto
- [087 · Corretor de seguros](prompts/07-financas-e-contabilidade/087-corretor-de-seguros.md) — Cobertura e condição lado a lado
- [088 · Consultor de crédito](prompts/07-financas-e-contabilidade/088-consultor-de-credito.md) — Proposta de crédito sem atalhos

## 08 · Marketing e produção de conteúdo — 14

[Abrir grupo completo](grupos/08-marketing-e-producao-de-conteudo.md)

- [089 · Criador de conteúdo / influenciador digital](prompts/08-marketing-e-producao-de-conteudo/089-criador-de-conteudo-influenciador-digital.md) — Autoria em primeiro plano
- [090 · Social media](prompts/08-marketing-e-producao-de-conteudo/090-social-media.md) — Calendário que revela a intenção
- [091 · Gestor de tráfego pago](prompts/08-marketing-e-producao-de-conteudo/091-gestor-de-trafego-pago.md) — Campanha com leitura de painel
- [092 · Estrategista de marketing digital](prompts/08-marketing-e-producao-de-conteudo/092-estrategista-de-marketing-digital.md) — Estratégia da intenção à evidência
- [093 · Copywriter](prompts/08-marketing-e-producao-de-conteudo/093-copywriter.md) — Argumento sob marcação editorial
- [094 · Editor de vídeo](prompts/08-marketing-e-producao-de-conteudo/094-editor-de-video.md) — Timeline com causa e resultado
- [095 · Videomaker](prompts/08-marketing-e-producao-de-conteudo/095-videomaker.md) — Bastidor que encontra o enquadramento
- [096 · Motion designer](prompts/08-marketing-e-producao-de-conteudo/096-motion-designer.md) — Movimento visto em camadas
- [097 · Designer gráfico](prompts/08-marketing-e-producao-de-conteudo/097-designer-grafico.md) — Hierarquia que orienta o olhar
- [098 · Fotógrafo](prompts/08-marketing-e-producao-de-conteudo/098-fotografo.md) — Luz, captura e leitura fiel
- [099 · Produtor audiovisual](prompts/08-marketing-e-producao-de-conteudo/099-produtor-audiovisual.md) — Produção ligada à entrega
- [100 · Produtor de podcast](prompts/08-marketing-e-producao-de-conteudo/100-produtor-de-podcast.md) — Conversa com trilhas legíveis
- [101 · Especialista em SEO](prompts/08-marketing-e-producao-de-conteudo/101-especialista-em-seo.md) — Da página ao diagnóstico visível
- [102 · Profissional de relações públicas](prompts/08-marketing-e-producao-de-conteudo/102-profissional-de-relacoes-publicas.md) — Mensagem, público e atribuição

## 09 · Comércio e empreendedorismo — 11

[Abrir grupo completo](grupos/09-comercio-e-empreendedorismo.md)

- [103 · Lojista](prompts/09-comercio-e-empreendedorismo/103-lojista.md) — Vitrine de detalhes reais
- [104 · Empreendedor de e-commerce](prompts/09-comercio-e-empreendedorismo/104-empreendedor-de-e-commerce.md) — Produto, pedido e bastidor
- [105 · Representante comercial](prompts/09-comercio-e-empreendedorismo/105-representante-comercial.md) — Portfólio por necessidade apresentada
- [106 · Consultor de vendas](prompts/09-comercio-e-empreendedorismo/106-consultor-de-vendas.md) — Atendimento com escuta e resposta
- [107 · Consultor empresarial](prompts/09-comercio-e-empreendedorismo/107-consultor-empresarial.md) — Processo com gargalo identificado
- [108 · Consultor de franquias](prompts/09-comercio-e-empreendedorismo/108-consultor-de-franquias.md) — Rede, unidade e decisão informada
- [109 · Especialista em marketplaces](prompts/09-comercio-e-empreendedorismo/109-especialista-em-marketplaces.md) — Anúncio acompanhado campo a campo
- [110 · Corretor de consórcios](prompts/09-comercio-e-empreendedorismo/110-corretor-de-consorcios.md) — Percurso condicionado do consórcio
- [111 · Leiloeiro](prompts/09-comercio-e-empreendedorismo/111-leiloeiro.md) — Lote com contexto de edital
- [112 · Consultor de importação](prompts/09-comercio-e-empreendedorismo/112-consultor-de-importacao.md) — Percurso logístico com responsáveis
- [113 · Gestor de produtos](prompts/09-comercio-e-empreendedorismo/113-gestor-de-produtos.md) — Problema, evidência e estado do produto

## 10 · Tecnologia e inteligência artificial — 11

[Abrir grupo completo](grupos/10-tecnologia-e-inteligencia-artificial.md)

- [114 · Programador](prompts/10-tecnologia-e-inteligencia-artificial/114-programador.md) — Código ligado à execução observada
- [115 · Desenvolvedor web](prompts/10-tecnologia-e-inteligencia-artificial/115-desenvolvedor-web.md) — Da estrutura à interface real
- [116 · Desenvolvedor de aplicativos](prompts/10-tecnologia-e-inteligencia-artificial/116-desenvolvedor-de-aplicativos.md) — Ação, tela e estado do aplicativo
- [117 · Cientista de dados](prompts/10-tecnologia-e-inteligencia-artificial/117-cientista-de-dados.md) — Dado, transformação e leitura
- [118 · Engenheiro de inteligência artificial](prompts/10-tecnologia-e-inteligencia-artificial/118-engenheiro-de-inteligencia-artificial.md) — Arquitetura de IA com limites visíveis
- [119 · Especialista em automação com IA](prompts/10-tecnologia-e-inteligencia-artificial/119-especialista-em-automacao-com-ia.md) — Gatilho até a execução documentada
- [120 · Analista de cibersegurança](prompts/10-tecnologia-e-inteligencia-artificial/120-analista-de-ciberseguranca.md) — Evidência e fronteira de segurança
- [121 · Designer UX/UI](prompts/10-tecnologia-e-inteligencia-artificial/121-designer-ux-ui.md) — Decisão de interface com evidência
- [122 · Desenvolvedor de jogos](prompts/10-tecnologia-e-inteligencia-artificial/122-desenvolvedor-de-jogos.md) — Da lógica ao gameplay registrado
- [123 · Técnico de informática](prompts/10-tecnologia-e-inteligencia-artificial/123-tecnico-de-informatica.md) — Componente, teste e constatação
- [124 · Especialista em no-code](prompts/10-tecnologia-e-inteligencia-artificial/124-especialista-em-no-code.md) — Bloco, dado e prévia conectados

## 11 · Gastronomia — 10

[Abrir grupo completo](grupos/11-gastronomia.md)

- [125 · Chef de cozinha](prompts/11-gastronomia/125-chef-de-cozinha.md) — Gesto culinário e transformação real
- [126 · Confeiteiro](prompts/11-gastronomia/126-confeiteiro.md) — Camadas e acabamento de confeitaria
- [127 · Padeiro](prompts/11-gastronomia/127-padeiro.md) — Massa em fases observáveis
- [128 · Churrasqueiro profissional](prompts/11-gastronomia/128-churrasqueiro-profissional.md) — Corte e execução sob observação
- [129 · Pizzaiolo](prompts/11-gastronomia/129-pizzaiolo.md) — Da abertura à borda real
- [130 · Barista](prompts/11-gastronomia/130-barista.md) — Extração e gesto em detalhe
- [131 · Bartender](prompts/11-gastronomia/131-bartender.md) — Ingrediente, medida e gesto do drinque
- [132 · Chocolatier](prompts/11-gastronomia/132-chocolatier.md) — Chocolate da etapa ao acabamento
- [133 · Sorveteiro artesanal](prompts/11-gastronomia/133-sorveteiro-artesanal.md) — Textura artesanal sob olhar próximo
- [134 · Cozinheiro de marmitas e delivery](prompts/11-gastronomia/134-cozinheiro-de-marmitas-e-delivery.md) — Montagem de refeição e operação real

## 12 · Moda, acessórios e perfumaria — 7

[Abrir grupo completo](grupos/12-moda-acessorios-e-perfumaria.md)

- [135 · Designer de moda](prompts/12-moda-acessorios-e-perfumaria/135-designer-de-moda.md) — Do traço à peça autoral
- [136 · Consultor de imagem e estilo](prompts/12-moda-acessorios-e-perfumaria/136-consultor-de-imagem-e-estilo.md) — Composição de estilo sem distorção
- [137 · Costureiro](prompts/12-moda-acessorios-e-perfumaria/137-costureiro.md) — Linha, gesto e acabamento de costura
- [138 · Joalheiro](prompts/12-moda-acessorios-e-perfumaria/138-joalheiro.md) — Peça de joalheria sob precisão visual
- [139 · Vendedor de semijoias](prompts/12-moda-acessorios-e-perfumaria/139-vendedor-de-semijoias.md) — Semijoia em composição fiel
- [140 · Consultor de perfumaria](prompts/12-moda-acessorios-e-perfumaria/140-consultor-de-perfumaria.md) — Notas sensoriais como relato visual
- [141 · Modelista de roupas](prompts/12-moda-acessorios-e-perfumaria/141-modelista-de-roupas.md) — Molde e peça em correspondência

## 13 · Imóveis, construção e decoração — 10

[Abrir grupo completo](grupos/13-imoveis-construcao-e-decoracao.md)

- [142 · Corretor de imóveis](prompts/13-imoveis-construcao-e-decoracao/142-corretor-de-imoveis.md) — Percurso imobiliário sem distorção
- [143 · Arquiteto](prompts/13-imoveis-construcao-e-decoracao/143-arquiteto.md) — Espaço, circulação e escolha arquitetônica
- [144 · Engenheiro civil](prompts/13-imoveis-construcao-e-decoracao/144-engenheiro-civil.md) — Componente, etapa e evidência de engenharia
- [145 · Designer de interiores](prompts/13-imoveis-construcao-e-decoracao/145-designer-de-interiores.md) — Material e uso no mesmo ambiente
- [146 · Decorador](prompts/13-imoveis-construcao-e-decoracao/146-decorador.md) — Composição decorativa em relações visíveis
- [147 · Paisagista](prompts/13-imoveis-construcao-e-decoracao/147-paisagista.md) — Paisagem entre plano e implantação
- [148 · Mestre de obras](prompts/13-imoveis-construcao-e-decoracao/148-mestre-de-obras.md) — Execução de obra com sequência legível
- [149 · Marceneiro](prompts/13-imoveis-construcao-e-decoracao/149-marceneiro.md) — Encaixe, montagem e acabamento real
- [150 · Pintor residencial](prompts/13-imoveis-construcao-e-decoracao/150-pintor-residencial.md) — Superfície e aplicação sem retoque
- [151 · Instalador de energia solar](prompts/13-imoveis-construcao-e-decoracao/151-instalador-de-energia-solar.md) — Componente solar e registro contextual

## 14 · Veterinária e mercado pet — 7

[Abrir grupo completo](grupos/14-veterinaria-e-mercado-pet.md)

- [152 · Médico-veterinário clínico](prompts/14-veterinaria-e-mercado-pet/152-medico-veterinario-clinico.md) — Percurso do cuidado animal
- [153 · Médico-veterinário dermatologista](prompts/14-veterinaria-e-mercado-pet/153-medico-veterinario-dermatologista.md) — Pele e pelagem em foco
- [154 · Médico-veterinário de animais exóticos](prompts/14-veterinaria-e-mercado-pet/154-medico-veterinario-de-animais-exoticos.md) — Espécie e ambiente conectados
- [155 · Adestrador de cães](prompts/14-veterinaria-e-mercado-pet/155-adestrador-de-caes.md) — Sinal, ação e resposta
- [156 · Tosador](prompts/14-veterinaria-e-mercado-pet/156-tosador.md) — Acabamento sob observação
- [157 · Comportamentalista animal](prompts/14-veterinaria-e-mercado-pet/157-comportamentalista-animal.md) — Contexto antes do rótulo
- [158 · Passeador de cães](prompts/14-veterinaria-e-mercado-pet/158-passeador-de-caes.md) — Percurso do passeio

## 15 · Turismo e eventos — 8

[Abrir grupo completo](grupos/15-turismo-e-eventos.md)

- [159 · Agente de viagens](prompts/15-turismo-e-eventos/159-agente-de-viagens.md) — Roteiro de viagem em camadas
- [160 · Guia de turismo](prompts/15-turismo-e-eventos/160-guia-de-turismo.md) — Lugar, detalhe e história
- [161 · Consultor de milhas aéreas](prompts/15-turismo-e-eventos/161-consultor-de-milhas-aereas.md) — Caminho dos pontos
- [162 · Consultor de intercâmbio](prompts/15-turismo-e-eventos/162-consultor-de-intercambio.md) — Etapas do intercâmbio
- [163 · Organizador de eventos](prompts/15-turismo-e-eventos/163-organizador-de-eventos.md) — Mapa da operação do evento
- [164 · Cerimonialista](prompts/15-turismo-e-eventos/164-cerimonialista.md) — Sequência do cerimonial
- [165 · Promotor de eventos](prompts/15-turismo-e-eventos/165-promotor-de-eventos.md) — Convite com informação clara
- [166 · Comissário de bordo](prompts/15-turismo-e-eventos/166-comissario-de-bordo.md) — Orientação de bordo visível

## 16 · Automóveis e motocicletas — 6

[Abrir grupo completo](grupos/16-automoveis-e-motocicletas.md)

- [167 · Mecânico automotivo](prompts/16-automoveis-e-motocicletas/167-mecanico-automotivo.md) — Falha, peça e funcionamento
- [168 · Mecânico de motocicletas](prompts/16-automoveis-e-motocicletas/168-mecanico-de-motocicletas.md) — Movimento do conjunto da moto
- [169 · Profissional de estética automotiva](prompts/16-automoveis-e-motocicletas/169-profissional-de-estetica-automotiva.md) — Superfície sob a mesma luz
- [170 · Eletricista automotivo](prompts/16-automoveis-e-motocicletas/170-eletricista-automotivo.md) — Circuito sob verificação
- [171 · Consultor automotivo](prompts/16-automoveis-e-motocicletas/171-consultor-automotivo.md) — Critérios lado a lado
- [172 · Instrutor de trânsito](prompts/16-automoveis-e-motocicletas/172-instrutor-de-transito.md) — Manobra vista por etapas

## 17 · Artes, comunicação, música e religião — 13

[Abrir grupo completo](grupos/17-artes-comunicacao-musica-e-religiao.md)

- [173 · Músico instrumentista](prompts/17-artes-comunicacao-musica-e-religiao/173-musico-instrumentista.md) — Gesto que produz o som
- [174 · Cantor](prompts/17-artes-comunicacao-musica-e-religiao/174-cantor.md) — Voz com espaço de expressão
- [175 · DJ](prompts/17-artes-comunicacao-musica-e-religiao/175-dj.md) — Transição musical observável
- [176 · Produtor musical](prompts/17-artes-comunicacao-musica-e-religiao/176-produtor-musical.md) — Escuta e camada em evidência
- [177 · Ator](prompts/17-artes-comunicacao-musica-e-religiao/177-ator.md) — Intenção em cena
- [178 · Dublador](prompts/17-artes-comunicacao-musica-e-religiao/178-dublador.md) — Voz e personagem sincronizados
- [179 · Escritor](prompts/17-artes-comunicacao-musica-e-religiao/179-escritor.md) — Texto, escolha e revisão
- [180 · Ilustrador](prompts/17-artes-comunicacao-musica-e-religiao/180-ilustrador.md) — Do traço à decisão
- [181 · Artesão](prompts/17-artes-comunicacao-musica-e-religiao/181-artesao.md) — Matéria em transformação
- [182 · Jornalista](prompts/17-artes-comunicacao-musica-e-religiao/182-jornalista.md) — Fonte, fato e contexto
- [183 · Apresentador de TV e rádio](prompts/17-artes-comunicacao-musica-e-religiao/183-apresentador-de-tv-e-radio.md) — Apresentação com respiro
- [184 · Pastor / líder religioso](prompts/17-artes-comunicacao-musica-e-religiao/184-pastor-lider-religioso.md) — Mensagem e referência preservadas
- [185 · Professor de música](prompts/17-artes-comunicacao-musica-e-religiao/185-professor-de-musica.md) — Escutar, ver e executar

## 18 · Agronegócio, serviços e outras profissões — 16

[Abrir grupo completo](grupos/18-agronegocio-servicos-e-outras-profissoes.md)

- [186 · Engenheiro agrônomo](prompts/18-agronegocio-servicos-e-outras-profissoes/186-engenheiro-agronomo.md) — Campo, amostra e leitura
- [187 · Médico-veterinário de grandes animais](prompts/18-agronegocio-servicos-e-outras-profissoes/187-medico-veterinario-de-grandes-animais.md) — Manejo e observação completos
- [188 · Zootecnista](prompts/18-agronegocio-servicos-e-outras-profissoes/188-zootecnista.md) — Sistema de criação explicado
- [189 · Produtor rural](prompts/18-agronegocio-servicos-e-outras-profissoes/189-produtor-rural.md) — Rotina rural com origem
- [190 · Técnico agrícola](prompts/18-agronegocio-servicos-e-outras-profissoes/190-tecnico-agricola.md) — Observação técnica no campo
- [191 · Florista](prompts/18-agronegocio-servicos-e-outras-profissoes/191-florista.md) — Composição floral em construção
- [192 · Eletricista residencial](prompts/18-agronegocio-servicos-e-outras-profissoes/192-eletricista-residencial.md) — Instalação com contexto visível
- [193 · Encanador](prompts/18-agronegocio-servicos-e-outras-profissoes/193-encanador.md) — Percurso da água explicado
- [194 · Técnico em refrigeração](prompts/18-agronegocio-servicos-e-outras-profissoes/194-tecnico-em-refrigeracao.md) — Ciclo e ponto observado
- [195 · Técnico em manutenção de celulares](prompts/18-agronegocio-servicos-e-outras-profissoes/195-tecnico-em-manutencao-de-celulares.md) — Detalhe técnico na bancada
- [196 · Personal organizer](prompts/18-agronegocio-servicos-e-outras-profissoes/196-personal-organizer.md) — Categoria, lugar e acesso
- [197 · Profissional de limpeza residencial](prompts/18-agronegocio-servicos-e-outras-profissoes/197-profissional-de-limpeza-residencial.md) — Processo de limpeza observável
- [198 · Jardineiro](prompts/18-agronegocio-servicos-e-outras-profissoes/198-jardineiro.md) — Jardim por áreas e gestos
- [199 · Doula](prompts/18-agronegocio-servicos-e-outras-profissoes/199-doula.md) — Acolhimento e presença
- [200 · Consultor de carreira](prompts/18-agronegocio-servicos-e-outras-profissoes/200-consultor-de-carreira.md) — Trajetória e próxima decisão
- [201 · Recrutador](prompts/18-agronegocio-servicos-e-outras-profissoes/201-recrutador.md) — Critério de seleção visível
