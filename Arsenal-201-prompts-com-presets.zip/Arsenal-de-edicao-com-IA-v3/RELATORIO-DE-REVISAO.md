# Revisão da versão 3.0.1

Foram conferidos 201 prompts e 201 perfis de direção, distribuídos em 18 áreas. Os nomes e grupos correspondem à lista oficial, e os textos individuais são idênticos aos blocos nos grupos, na coletânea e no catálogo.

As combinações completas e os nomes são únicos. A diferença inclui o motivo visual e a cena adequada à profissão; isso não significa 201 motores ou 201 efeitos nativos diferentes. Todos os perfis foram revistos editorialmente, com checagem dos componentes e fontes referenciados.

As cores foram conferidas em 402 comparações de contraste entre amostras: texto/base e destaque/base. Esse cálculo não substitui a inspeção sobre o vídeo real. Foram conferidos consumidores do motor para base, destaque, pares de ênfase, planos, recuo, listas, órbitas, texto atrás, cenas e legenda. Isso comprova o caminho de implementação, não que uma edição já tenha sido renderizada.

A revisão preservou 241 arquivos das entregas anteriores e os 65 arquivos da skill comparados ao inventário da auditoria. Nenhum código ou ativo da skill foi incluído neste pacote. PDF e página ficaram pausados.

## O que ainda precisa de teste

Não foram executadas edições de vídeo nesta revisão. Todos os 201 perfis novos estão marcados como pendentes de teste. A aprovação externa relatada para o arquiteto pertence à versão anterior e não foi transferida ao novo perfil.

Os testes estruturais não comprovam ausência de bugs, correção anatômica, qualidade da transcrição ou sincronismo de um vídeo futuro. O controle de testes contém um representante por grupo e linhas para validar cada profissão. A validação final exige assistir e ouvir o MP4, conferir a fidelidade ao conteúdo e registrar o resultado.

## Critérios mantidos

- Projeto exclusivo, preservação do original e da instalação global.
- Aprovações da fala limpa e do vídeo de revisão, com a mesma regra de continuidade em 201 prompts.
- Prioridade a preferências, referências e demonstração real; adaptação ao vídeo em vez de efeitos obrigatórios.
- Gatilhos na fala, sincronização desde a abertura e atualização dos tempos quando a montagem muda.
- Receitas e legendas personalizadas implementadas na cópia do projeto, sem inventar seletores.
- Figuras 3D condicionadas a material correto e compatível; alternativa 2D quando não houver.
- Conferência dos resultados reais dos verificadores, do MP4 inteiro e das regiões protegidas.
