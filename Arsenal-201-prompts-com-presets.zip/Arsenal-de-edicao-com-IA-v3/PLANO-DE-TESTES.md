# Testes das direções de edição

Os 201 prompts desta revisão precisam de teste em vídeo. O arquiteto v2 teve aprovação externa informada pelo usuário; o novo perfil não herda essa aprovação. Testar um representante por grupo ajuda a avaliar o padrão, mas não aprova automaticamente os demais.

## Verificação do vídeo

1. Confira arquivo e preservação do original. Ouça a fala limpa inteira: palavras, negações, pausas, escolhas de tomadas e CTA.
2. Compare fala e apoio visual desde a abertura. Confira se cada etapa relevante tem imagem correspondente ou demonstração real visível, sem atraso.
3. Confira fidelidade dos termos, unidades, figuras e materiais. Identifique os esquemas ilustrativos.
4. Leia as legendas; confira contraste e se ocultam rosto, mãos, detalhes e informações.
5. Confira a combinação implementada e se há efeitos a mais. Preserve a duração de gestos, processos e performances.
6. Assista e ouça o MP4 inteiro; registre problemas com tempo, esperado e observado. Faça uma nova conferência dos trechos alterados e suas junções.
7. Registre versão do prompt, skill, vídeo, escolhas e resultado em CONTROLE-DE-TESTES.csv.

## Representantes para começar

| Área | Prompt e preset | Ideia de teste |
|---|---|---|
| Medicina | [004 · Médico cardiologista](prompts/01-medicina/004-medico-cardiologista.md) — Percurso do coração | Explique a localização de uma estrutura cardíaca utilizando um modelo ou desenho de referência. |
| Outras profissões da saúde | [023 · Dentista clínico geral](prompts/02-outras-profissoes-da-saude/023-dentista-clinico-geral.md) — Dente e processo sincronizados | Explique em um modelo a organização do dente e destaque as estruturas que você nomear. |
| Beleza e estética | [038 · Barbeiro](prompts/03-beleza-e-estetica/038-barbeiro.md) — Degradê em faixas claras | Explique uma etapa de acabamento em manequim, mantendo ferramenta e região trabalhada sempre visíveis. |
| Fitness e esportes | [049 · Personal trainer](prompts/04-fitness-e-esportes/049-personal-trainer.md) — Repetição completa e clara | Demonstre um exercício escolhido por você e explique duas fases que devem permanecer visíveis. |
| Educação | [059 · Professor de matemática](prompts/05-educacao/059-professor-de-matematica.md) — Raciocínio em linhas preservadas | Resolva um exercício autoral curto, fornecendo enunciado e cada passagem escrita para conferir na edição. |
| Direito | [070 · Advogado trabalhista](prompts/06-direito/070-advogado-trabalhista.md) — Fatos e documentos em sequência | Explique como organiza os documentos recebidos antes de analisar uma dúvida trabalhista. |
| Finanças e contabilidade | [081 · Contador](prompts/07-financas-e-contabilidade/081-contador.md) — Documento que vira lançamento | Mostre como organiza uma pasta de documentos e uma planilha demonstrativa sem dados de clientes. |
| Marketing e produção de conteúdo | [094 · Editor de vídeo](prompts/08-marketing-e-producao-de-conteudo/094-editor-de-video.md) — Timeline com causa e resultado | Mostre um corte simples com arquivos próprios e compare a reprodução antes e depois. |
| Comércio e empreendedorismo | [103 · Lojista](prompts/09-comercio-e-empreendedorismo/103-lojista.md) — Vitrine de detalhes reais | Apresente um produto real da loja e mostre dois detalhes visíveis, sem prometer resultados de uso. |
| Tecnologia e inteligência artificial | [115 · Desenvolvedor web](prompts/10-tecnologia-e-inteligencia-artificial/115-desenvolvedor-web.md) — Da estrutura à interface real | Mostre uma alteração própria de estilo e o resultado real no navegador, antes e depois. |
| Gastronomia | [125 · Chef de cozinha](prompts/11-gastronomia/125-chef-de-cozinha.md) — Gesto culinário e transformação real | Explique uma etapa de preparo conhecida, mostrando mãos e ingredientes reais sem omitir o movimento principal. |
| Moda, acessórios e perfumaria | [137 · Costureiro](prompts/12-moda-acessorios-e-perfumaria/137-costureiro.md) — Linha, gesto e acabamento de costura | Demonstre uma dobra ou acabamento em uma amostra própria, mantendo mãos, marcação e resultado visíveis. |
| Imóveis, construção e decoração | [143 · Arquiteto](prompts/13-imoveis-construcao-e-decoracao/143-arquiteto.md) — Espaço, circulação e escolha arquitetônica | Explique uma relação entre mobiliário e circulação usando um relato ou uma planta identificada. |
| Veterinária e mercado pet | [152 · Médico-veterinário clínico](prompts/14-veterinaria-e-mercado-pet/152-medico-veterinario-clinico.md) — Percurso do cuidado animal | Explique como apresentar um registro de consulta sem dados identificáveis e sem orientar tratamento individual. |
| Turismo e eventos | [159 · Agente de viagens](prompts/15-turismo-e-eventos/159-agente-de-viagens.md) — Roteiro de viagem em camadas | Explique um roteiro de exemplo usando destinos identificados, sem apresentar preços ou condições não confirmados. |
| Automóveis e motocicletas | [167 · Mecânico automotivo](prompts/16-automoveis-e-motocicletas/167-mecanico-automotivo.md) — Falha, peça e funcionamento | Explique a função de um componente disponível em bancada sem propor diagnóstico de um veículo específico. |
| Artes, comunicação, música e religião | [173 · Músico instrumentista](prompts/17-artes-comunicacao-musica-e-religiao/173-musico-instrumentista.md) — Gesto que produz o som | Toque e explique um trecho próprio curto, mostrando as mãos e mantendo o mesmo áudio da gravação. |
| Agronegócio, serviços e outras profissões | [192 · Eletricista residencial](prompts/18-agronegocio-servicos-e-outras-profissoes/192-eletricista-residencial.md) — Instalação com contexto visível | Explique a função de componentes em um esquema fornecido, sem criar instruções de intervenção na instalação. |
